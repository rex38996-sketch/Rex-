/**
 * @jarvis/ai-adapter - provider-independent AI layer.
 *
 * Import only from here. The application never imports a vendor SDK directly,
 * which is what guarantees "changing an AI provider must not require
 * rebuilding the application" (blueprint section 39).
 */
export * from './types.js';
export * from './registry.js';
export * from './router.js';
export { MockProvider, createMockProvider } from './providers/mock.js';
export {
  OpenAICompatibleProvider,
  createOpenAICompatibleProvider,
} from './providers/openai-compatible.js';
