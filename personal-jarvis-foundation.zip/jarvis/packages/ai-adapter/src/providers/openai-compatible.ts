import type {
  AIProvider,
  ChatRequest,
  ChatResponse,
  ChatStreamEvent,
  EmbeddingRequest,
  EmbeddingResponse,
  ProviderConfig,
  ProviderHealth,
  ProviderModel,
  TokenUsage,
} from '../types.js';

/**
 * Adapter for any OpenAI-compatible HTTP API (OpenAI, Azure OpenAI, Groq,
 * Together, OpenRouter, local vLLM/Ollama, ...). Because the wire format is
 * shared, one adapter unlocks many vendors — the key provider-independence
 * win called for in blueprint section 39.
 */
export class OpenAICompatibleProvider implements AIProvider {
  readonly id: string;
  readonly kind = 'openai_compatible';
  readonly label: string;
  private readonly baseUrl: string;
  private readonly apiKey: string;
  private readonly headers: Record<string, string>;
  private readonly timeoutMs: number;

  constructor(config: ProviderConfig) {
    this.id = config.id;
    this.label = config.label;
    this.baseUrl = config.baseUrl.replace(/\/+$/, '');
    this.apiKey = config.apiKey;
    this.headers = {
      'content-type': 'application/json',
      ...(config.apiKey ? { authorization: `Bearer ${config.apiKey}` } : {}),
      ...config.headers,
    };
    this.timeoutMs = config.timeoutMs ?? 60_000;
  }

  private url(path: string): string {
    return `${this.baseUrl}${path}`;
  }

  private async post(path: string, body: unknown, signal?: AbortSignal): Promise<Response> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeoutMs);
    const onAbort = () => controller.abort();
    signal?.addEventListener('abort', onAbort, { once: true });
    try {
      return await fetch(this.url(path), {
        method: 'POST',
        headers: this.headers,
        body: JSON.stringify(body),
        signal: controller.signal,
      });
    } finally {
      clearTimeout(timer);
      signal?.removeEventListener('abort', onAbort);
    }
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    const res = await this.post(
      '/chat/completions',
      {
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
        max_tokens: request.maxTokens,
        stream: false,
        ...request.extra,
      },
      request.signal,
    );
    if (!res.ok) {
      throw new Error(`Provider ${this.id} chat failed: ${res.status} ${await res.text()}`);
    }
    const data = (await res.json()) as any;
    const choice = data.choices?.[0];
    const usage: TokenUsage = {
      inputTokens: data.usage?.prompt_tokens ?? 0,
      outputTokens: data.usage?.completion_tokens ?? 0,
      totalTokens: data.usage?.total_tokens ?? 0,
    };
    return {
      content: choice?.message?.content ?? '',
      model: data.model ?? request.model,
      finishReason: mapFinishReason(choice?.finish_reason),
      usage,
      raw: data,
    };
  }

  async *chatStream(request: ChatRequest): AsyncIterable<ChatStreamEvent> {
    const res = await this.post(
      '/chat/completions',
      {
        model: request.model,
        messages: request.messages,
        temperature: request.temperature,
        max_tokens: request.maxTokens,
        stream: true,
        stream_options: { include_usage: true },
        ...request.extra,
      },
      request.signal,
    );
    if (!res.ok || !res.body) {
      throw new Error(`Provider ${this.id} stream failed: ${res.status} ${await res.text()}`);
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let finishReason: ChatResponse['finishReason'] = 'stop';
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';
      for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed.startsWith('data:')) continue;
        const payload = trimmed.slice(5).trim();
        if (payload === '[DONE]') continue;
        let json: any;
        try {
          json = JSON.parse(payload);
        } catch {
          continue;
        }
        const delta = json.choices?.[0]?.delta?.content;
        if (delta) yield { type: 'delta', content: delta };
        if (json.choices?.[0]?.finish_reason) {
          finishReason = mapFinishReason(json.choices[0].finish_reason);
        }
        if (json.usage) {
          yield {
            type: 'usage',
            usage: {
              inputTokens: json.usage.prompt_tokens ?? 0,
              outputTokens: json.usage.completion_tokens ?? 0,
              totalTokens: json.usage.total_tokens ?? 0,
            },
          };
        }
      }
    }
    yield { type: 'done', finishReason };
  }

  async embed(request: EmbeddingRequest): Promise<EmbeddingResponse> {
    const res = await this.post('/embeddings', { model: request.model, input: request.input });
    if (!res.ok) {
      throw new Error(`Provider ${this.id} embed failed: ${res.status} ${await res.text()}`);
    }
    const data = (await res.json()) as any;
    return {
      embeddings: (data.data ?? []).map((d: any) => d.embedding),
      model: data.model ?? request.model,
      usage: {
        inputTokens: data.usage?.prompt_tokens ?? 0,
        outputTokens: 0,
        totalTokens: data.usage?.total_tokens ?? 0,
      },
    };
  }

  async listModels(): Promise<ProviderModel[]> {
    const res = await fetch(this.url('/models'), { headers: this.headers });
    if (!res.ok) return [];
    const data = (await res.json()) as any;
    return (data.data ?? []).map((m: any) => ({
      key: m.id,
      displayName: m.id,
      capabilities: [],
      contextWindow: 0,
    }));
  }

  async healthCheck(): Promise<ProviderHealth> {
    const started = Date.now();
    try {
      const res = await fetch(this.url('/models'), { headers: this.headers });
      return { ok: res.ok, latencyMs: Date.now() - started, message: res.statusText };
    } catch (err) {
      return { ok: false, latencyMs: Date.now() - started, message: (err as Error).message };
    }
  }
}

function mapFinishReason(reason: string | undefined): ChatResponse['finishReason'] {
  switch (reason) {
    case 'length':
      return 'length';
    case 'tool_calls':
      return 'tool_calls';
    case 'stop':
      return 'stop';
    default:
      return 'stop';
  }
}

export const createOpenAICompatibleProvider = (config: ProviderConfig): AIProvider =>
  new OpenAICompatibleProvider(config);
