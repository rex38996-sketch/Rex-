import type {
  AIProvider,
  ChatRequest,
  ChatResponse,
  ChatStreamEvent,
  EmbeddingRequest,
  EmbeddingResponse,
  ProviderConfig,
  ProviderHealth,
  ProviderModel,
} from '../types.js';

/**
 * A deterministic, dependency-free provider used for local development and
 * tests. It proves the platform runs end-to-end with zero credentials and
 * gives the test-suite a stable target.
 */
export class MockProvider implements AIProvider {
  readonly id: string;
  readonly kind = 'mock';
  readonly label: string;

  constructor(private readonly config: ProviderConfig) {
    this.id = config.id;
    this.label = config.label;
  }

  async chat(request: ChatRequest): Promise<ChatResponse> {
    const lastUser = [...request.messages].reverse().find((m) => m.role === 'user');
    const content = `[mock:${request.model}] ${lastUser?.content ?? '(no input)'}`;
    const inputTokens = estimateTokens(request.messages.map((m) => m.content).join(' '));
    const outputTokens = estimateTokens(content);
    return {
      content,
      model: request.model,
      finishReason: 'stop',
      usage: {
        inputTokens,
        outputTokens,
        totalTokens: inputTokens + outputTokens,
      },
      raw: { provider: 'mock' },
    };
  }

  async *chatStream(request: ChatRequest): AsyncIterable<ChatStreamEvent> {
    const full = await this.chat({ ...request, stream: true });
    const words = full.content.split(' ');
    for (const word of words) {
      yield { type: 'delta', content: word + ' ' };
    }
    yield { type: 'usage', usage: full.usage };
    yield { type: 'done', finishReason: full.finishReason };
  }

  async embed(request: EmbeddingRequest): Promise<EmbeddingResponse> {
    // Deterministic pseudo-embeddings: hash tokens into a fixed-dim vector.
    const dims = 32;
    const embeddings = request.input.map((text) => {
      const vec = new Array<number>(dims).fill(0);
      for (const token of text.toLowerCase().split(/\s+/).filter(Boolean)) {
        let h = 0;
        for (let i = 0; i < token.length; i++) h = (h * 31 + token.charCodeAt(i)) >>> 0;
        const idx = h % dims;
        vec[idx] = (vec[idx] ?? 0) + 1;
      }
      const norm = Math.sqrt(vec.reduce((s, v) => s + v * v, 0)) || 1;
      return vec.map((v) => v / norm);
    });
    return {
      embeddings,
      model: request.model,
      usage: { inputTokens: 0, outputTokens: 0, totalTokens: 0 },
    };
  }

  async listModels(): Promise<ProviderModel[]> {
    return [
      {
        key: 'mock-fast',
        displayName: 'Mock Fast',
        capabilities: ['fast', 'cheap'],
        contextWindow: 8192,
      },
      {
        key: 'mock-reasoning',
        displayName: 'Mock Reasoning',
        capabilities: ['reasoning', 'research'],
        contextWindow: 32768,
      },
    ];
  }

  async healthCheck(): Promise<ProviderHealth> {
    return { ok: true, latencyMs: 0, message: 'mock provider always healthy' };
  }
}

function estimateTokens(text: string): number {
  return Math.max(1, Math.ceil(text.length / 4));
}

export const createMockProvider = (config: ProviderConfig): AIProvider => new MockProvider(config);
