import type { AIProvider, ProviderConfig, ProviderFactory } from './types.js';
import { createMockProvider } from './providers/mock.js';
import { createOpenAICompatibleProvider } from './providers/openai-compatible.js';

/**
 * Central registry mapping adapter "kinds" to factories, and holding the live
 * provider instances configured from the Admin Panel. Adding a new vendor is
 * a one-line `register()` call — no changes anywhere else in the app.
 */
export class ProviderRegistry {
  private readonly factories = new Map<string, ProviderFactory>();
  private readonly instances = new Map<string, AIProvider>();
  private readonly configs = new Map<string, ProviderConfig>();

  register(kind: string, factory: ProviderFactory): this {
    this.factories.set(kind, factory);
    return this;
  }

  hasKind(kind: string): boolean {
    return this.factories.has(kind);
  }

  kinds(): string[] {
    return [...this.factories.keys()];
  }

  /** Instantiate (or re-instantiate) a provider from its config. */
  add(config: ProviderConfig): AIProvider {
    const factory = this.factories.get(config.kind);
    if (!factory) {
      throw new Error(
        `Unknown provider kind "${config.kind}". Registered: ${this.kinds().join(', ') || '(none)'}`,
      );
    }
    const provider = factory(config);
    this.instances.set(config.id, provider);
    this.configs.set(config.id, config);
    return provider;
  }

  remove(id: string): void {
    this.instances.delete(id);
    this.configs.delete(id);
  }

  get(id: string): AIProvider {
    const provider = this.instances.get(id);
    if (!provider) throw new Error(`Provider "${id}" is not registered`);
    return provider;
  }

  tryGet(id: string): AIProvider | undefined {
    return this.instances.get(id);
  }

  config(id: string): ProviderConfig | undefined {
    return this.configs.get(id);
  }

  list(): AIProvider[] {
    return [...this.instances.values()];
  }

  /** Enabled providers ordered by ascending priority for failover. */
  orderedEnabled(): AIProvider[] {
    return [...this.configs.values()]
      .filter((c) => c.enabled)
      .sort((a, b) => a.priority - b.priority)
      .map((c) => this.get(c.id));
  }
}

/** A registry preloaded with the built-in adapters. */
export function createDefaultRegistry(): ProviderRegistry {
  return new ProviderRegistry()
    .register('mock', createMockProvider)
    .register('openai_compatible', createOpenAICompatibleProvider);
}
