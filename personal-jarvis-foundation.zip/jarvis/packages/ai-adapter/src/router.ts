import type { Capability, ModelConfig } from '@jarvis/core';
import type { AIProvider, ChatRequest, ChatResponse, RoutingDecision } from './types.js';

/** Describes the shape of an incoming task so a model can be chosen for it. */
export interface TaskProfile {
  /** Capabilities the task needs, best-first. */
  needs: Capability[];
  /** Prefer the cheapest capable model. */
  preferCheap?: boolean;
  /** Explicit model override from the user or conversation. */
  forceModelId?: string;
}

/**
 * Chooses which configured model should serve a task. This is the routing
 * brain behind blueprint section 2's "simple -> fast, complex -> reasoning,
 * coding -> coding" behaviour, and it also drives failover.
 */
export class ModelRouter {
  constructor(private readonly models: ModelConfig[]) {}

  private candidates(): ModelConfig[] {
    return this.models.filter((m) => m.enabled);
  }

  /** Score a model against a task; higher is better. Returns null if unusable. */
  private score(model: ModelConfig, profile: TaskProfile): number | null {
    if (!model.enabled) return null;
    let score = 0;
    let matched = 0;
    for (const need of profile.needs) {
      if (model.capabilities.includes(need)) {
        matched += 1;
        // Earlier needs matter more.
        score += 10 - profile.needs.indexOf(need);
      }
    }
    if (profile.needs.length > 0 && matched === 0) return null;
    score += model.priority; // admin-configured tie-breaker
    if (model.isDefault) score += 1;
    if (profile.preferCheap) score -= model.costPer1kOutput;
    return score;
  }

  route(profile: TaskProfile): RoutingDecision {
    if (profile.forceModelId) {
      const forced = this.models.find((m) => m.id === profile.forceModelId);
      if (!forced) throw new Error(`Forced model "${profile.forceModelId}" not found`);
      if (!forced.enabled) throw new Error(`Forced model "${forced.name}" is disabled`);
      return { model: forced, providerId: forced.providerId, reason: 'manual selection' };
    }

    const ranked = this.candidates()
      .map((model) => ({ model, score: this.score(model, profile) }))
      .filter((x): x is { model: ModelConfig; score: number } => x.score !== null)
      .sort((a, b) => b.score - a.score);

    if (ranked.length === 0) {
      throw new Error(`No enabled model satisfies capabilities: ${profile.needs.join(', ')}`);
    }
    const best = ranked[0]!;
    return {
      model: best.model,
      providerId: best.model.providerId,
      reason: `capabilities=[${profile.needs.join(',')}]`,
    };
  }
}

/**
 * Executes a chat request against a provider, falling back through the
 * ordered provider list if the primary fails (blueprint sections 33-34).
 * The router picks the model; the caller supplies the provider lookup.
 */
export async function chatWithFallback(
  request: ChatRequest,
  providers: AIProvider[],
): Promise<{ response: ChatResponse; providerId: string; attempts: string[] }> {
  const attempts: string[] = [];
  let lastError: unknown;
  for (const provider of providers) {
    attempts.push(provider.id);
    try {
      const response = await provider.chat(request);
      return { response, providerId: provider.id, attempts };
    } catch (err) {
      lastError = err;
    }
  }
  throw new Error(
    `All providers failed after [${attempts.join(', ')}]: ${(lastError as Error)?.message ?? 'unknown'}`,
  );
}
