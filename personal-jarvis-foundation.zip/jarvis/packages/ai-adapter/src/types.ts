import type { Capability, ModelConfig } from '@jarvis/core';

/**
 * The single contract every AI provider must satisfy. The rest of the
 * application only ever talks to this interface, never to a vendor SDK, so a
 * provider can be added or swapped from the Admin Panel without touching
 * memory, tools, or the UI (blueprint sections 39 & 52).
 */

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant' | 'tool';
  content: string;
  /** Present when role === 'tool'. */
  toolCallId?: string;
  name?: string;
}

export interface ChatRequest {
  /** Provider-side model key, e.g. "gpt-4o" or "claude-3-5-sonnet". */
  model: string;
  messages: ChatMessage[];
  temperature?: number;
  maxTokens?: number;
  stream?: boolean;
  /** Opaque passthrough for provider-specific knobs. */
  extra?: Record<string, unknown>;
  signal?: AbortSignal;
}

export interface TokenUsage {
  inputTokens: number;
  outputTokens: number;
  totalTokens: number;
}

export interface ChatResponse {
  content: string;
  model: string;
  finishReason: 'stop' | 'length' | 'tool_calls' | 'error';
  usage: TokenUsage;
  /** Raw provider payload, retained for logging/debugging. */
  raw?: unknown;
}

export type ChatStreamEvent =
  | { type: 'delta'; content: string }
  | { type: 'usage'; usage: TokenUsage }
  | { type: 'done'; finishReason: ChatResponse['finishReason'] };

export interface EmbeddingRequest {
  model: string;
  input: string[];
}

export interface EmbeddingResponse {
  embeddings: number[][];
  model: string;
  usage: TokenUsage;
}

export interface ProviderModel {
  /** Provider-side key. */
  key: string;
  displayName: string;
  capabilities: Capability[];
  contextWindow: number;
}

export interface ProviderHealth {
  ok: boolean;
  latencyMs: number | null;
  message?: string;
}

/** Everything a provider needs to operate, supplied by the Admin Panel. */
export interface ProviderConfig {
  id: string;
  /** Adapter type, e.g. "openai_compatible" | "mock". */
  kind: string;
  label: string;
  baseUrl: string;
  /** Resolved server-side only; never serialised to clients. */
  apiKey: string;
  /** Extra headers (auth variants, org ids, ...). */
  headers?: Record<string, string>;
  timeoutMs?: number;
  enabled: boolean;
  /** Lower number = tried first during failover. */
  priority: number;
}

export interface AIProvider {
  readonly id: string;
  readonly kind: string;
  readonly label: string;
  chat(request: ChatRequest): Promise<ChatResponse>;
  chatStream(request: ChatRequest): AsyncIterable<ChatStreamEvent>;
  embed(request: EmbeddingRequest): Promise<EmbeddingResponse>;
  listModels(): Promise<ProviderModel[]>;
  healthCheck(): Promise<ProviderHealth>;
}

/** Factory signature each adapter module exports. */
export type ProviderFactory = (config: ProviderConfig) => AIProvider;

export interface RoutingDecision {
  model: ModelConfig;
  providerId: string;
  reason: string;
}
