/** Core domain types shared across every subsystem. */

export type ISODateString = string;

/** Roles, ordered from most to least privileged (blueprint section 22). */
export type Role = 'owner' | 'super_admin' | 'admin' | 'editor' | 'user' | 'guest';

/** Discrete actions a permission can be granted for (blueprint section 23). */
export type Action = 'view' | 'use' | 'edit' | 'delete' | 'execute' | 'configure';

export type PermissionLevel = 'allowed' | 'approval_required' | 'blocked';

export interface User {
  id: string;
  email: string;
  displayName: string;
  role: Role;
  passwordHash: string;
  createdAt: ISODateString;
  updatedAt: ISODateString;
  disabled: boolean;
}

/** A safe projection of a User that is safe to send to clients. */
export type PublicUser = Omit<User, 'passwordHash'>;

export interface Session {
  id: string;
  userId: string;
  tokenHash: string;
  createdAt: ISODateString;
  expiresAt: ISODateString;
  revokedAt: ISODateString | null;
  userAgent?: string;
  ip?: string;
}

export type ConversationStatus = 'active' | 'archived';

export interface Conversation {
  id: string;
  userId: string;
  title: string;
  folderId: string | null;
  status: ConversationStatus;
  pinned: boolean;
  agentId: string | null;
  modelId: string | null;
  /** Per-conversation toggles (blueprint section 45). */
  useMemory: boolean;
  useKnowledge: boolean;
  useWeb: boolean;
  useTools: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export type MessageRole = 'system' | 'user' | 'assistant' | 'tool';

export interface Message {
  id: string;
  conversationId: string;
  role: MessageRole;
  content: string;
  /** Model that produced an assistant message. */
  modelId: string | null;
  agentId: string | null;
  /** Knowledge/memory citations attached to this message. */
  citations: Citation[];
  tokenInput: number | null;
  tokenOutput: number | null;
  createdAt: ISODateString;
}

export interface Citation {
  sourceType: 'knowledge' | 'memory' | 'web';
  sourceId: string;
  title: string;
  chapter?: string;
  page?: number;
  section?: string;
  url?: string;
  snippet?: string;
}

/** Agent capability tags used by the model router (blueprint section 32). */
export type Capability =
  | 'reasoning'
  | 'coding'
  | 'vision'
  | 'long_context'
  | 'fast'
  | 'cheap'
  | 'research'
  | 'audio';

export interface ModelConfig {
  id: string;
  providerId: string;
  name: string;
  /** Provider-side model identifier, e.g. "gpt-4o". */
  modelKey: string;
  capabilities: Capability[];
  contextWindow: number;
  /** Cost in USD per 1K tokens. */
  costPer1kInput: number;
  costPer1kOutput: number;
  priority: number;
  isDefault: boolean;
  enabled: boolean;
}

export interface Agent {
  id: string;
  name: string;
  description: string;
  avatar: string | null;
  personality: string;
  systemPrompt: string;
  modelId: string | null;
  temperature: number;
  memoryAccess: boolean;
  knowledgeAccess: boolean;
  webAccess: boolean;
  fileAccess: boolean;
  browserAccess: boolean;
  computerAccess: boolean;
  /** Tool ids this agent may call. Empty = none. */
  toolIds: string[];
  allowedActions: Action[];
  restrictions: string[];
  responseStyle: string;
  language: string;
  outputFormat: string;
  version: number;
  isBuiltIn: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

/** Memory modes (blueprint section 5). */
export type MemoryMode = 'auto_save' | 'ask_before_save' | 'manual_only' | 'disabled';

export type MemoryKind =
  | 'short_term'
  | 'long_term'
  | 'episodic'
  | 'semantic'
  | 'manual'
  | 'agent';

export interface Memory {
  id: string;
  userId: string | null;
  agentId: string | null;
  kind: MemoryKind;
  content: string;
  category: string | null;
  importance: number; // 0..1
  confidence: number; // 0..1
  source: string | null;
  pinned: boolean;
  locked: boolean;
  approved: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface KnowledgeBase {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export type DocumentStatus =
  | 'uploaded'
  | 'parsing'
  | 'ocr'
  | 'chunking'
  | 'embedding'
  | 'ready'
  | 'failed';

export interface Document {
  id: string;
  knowledgeBaseId: string;
  title: string;
  mimeType: string;
  sizeBytes: number;
  storageKey: string;
  version: number;
  status: DocumentStatus;
  error: string | null;
  pageCount: number | null;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface DocumentChunk {
  id: string;
  documentId: string;
  index: number;
  content: string;
  chapter: string | null;
  page: number | null;
  section: string | null;
  tokenCount: number;
}

/** Permission levels for the computer/browser agents (blueprint sections 12-13). */
export interface AgentPermissions {
  browserRead: PermissionLevel;
  browserClick: PermissionLevel;
  browserType: PermissionLevel;
  computerControl: PermissionLevel;
  purchase: PermissionLevel;
  delete: PermissionLevel;
  sendMessage: PermissionLevel;
  changeSettings: PermissionLevel;
  runCommand: PermissionLevel;
}

export const DEFAULT_AGENT_PERMISSIONS: AgentPermissions = {
  browserRead: 'allowed',
  browserClick: 'allowed',
  browserType: 'approval_required',
  computerControl: 'approval_required',
  purchase: 'approval_required',
  delete: 'blocked',
  sendMessage: 'approval_required',
  changeSettings: 'approval_required',
  runCommand: 'approval_required',
};

export type ApprovalStatus = 'pending' | 'approved' | 'rejected' | 'expired';

export interface ApprovalRequest {
  id: string;
  userId: string;
  agentId: string | null;
  action: keyof AgentPermissions | string;
  description: string;
  payload: Record<string, unknown>;
  status: ApprovalStatus;
  createdAt: ISODateString;
  resolvedAt: ISODateString | null;
  resolvedBy: string | null;
}
