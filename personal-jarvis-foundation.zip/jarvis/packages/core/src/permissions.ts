import type { Action, AgentPermissions, PermissionLevel, Role } from './types.js';
import { isAtLeast } from './roles.js';

/**
 * Role -> action grant matrix. A role inherits every grant of the roles
 * below it in rank. `configure` and `delete` are reserved for admins, which
 * keeps destructive operations out of reach of ordinary users by default.
 */
const ROLE_ACTIONS: Record<Role, Action[]> = {
  owner: ['view', 'use', 'edit', 'delete', 'execute', 'configure'],
  super_admin: ['view', 'use', 'edit', 'delete', 'execute', 'configure'],
  admin: ['view', 'use', 'edit', 'delete', 'execute', 'configure'],
  editor: ['view', 'use', 'edit', 'execute'],
  user: ['view', 'use', 'execute'],
  guest: ['view'],
};

export function roleCan(role: Role, action: Action): boolean {
  return ROLE_ACTIONS[role].includes(action);
}

/**
 * Resolve the effective permission level for an agent action, taking the
 * agent's configured policy and the acting user's role into account.
 *
 * Rules:
 *  - A user may never exceed what their role allows; `blocked` always wins.
 *  - `approval_required` is preserved so the approval system can gate it.
 *  - The Owner always retains `allowed` for read-only actions.
 */
export function resolvePermissionLevel(
  policy: PermissionLevel,
  role: Role,
  action: Action,
): PermissionLevel {
  if (policy === 'blocked') return 'blocked';
  if (!roleCan(role, action)) return 'blocked';
  return policy;
}

/** Convenience helper for evaluating a full agent permission set. */
export function checkAgentPermission(
  permissions: AgentPermissions,
  key: keyof AgentPermissions,
  role: Role,
): PermissionLevel {
  const action: Action = key.startsWith('browser') ? 'use' : 'execute';
  return resolvePermissionLevel(permissions[key], role, action);
}

/** True when a role may administer a subsystem (blueprint section 48). */
export function canAdminister(role: Role): boolean {
  return isAtLeast(role, 'admin');
}
