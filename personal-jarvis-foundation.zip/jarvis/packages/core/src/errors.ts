/** Typed error hierarchy so API layers can map errors to HTTP cleanly. */

export class AppError extends Error {
  readonly status: number;
  readonly code: string;
  readonly details?: unknown;

  constructor(message: string, status = 500, code = 'internal_error', details?: unknown) {
    super(message);
    this.name = new.target.name;
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export class ValidationError extends AppError {
  constructor(message = 'Invalid input', details?: unknown) {
    super(message, 400, 'validation_error', details);
  }
}

export class UnauthorizedError extends AppError {
  constructor(message = 'Authentication required') {
    super(message, 401, 'unauthorized');
  }
}

export class ForbiddenError extends AppError {
  constructor(message = 'Not permitted') {
    super(message, 403, 'forbidden');
  }
}

export class NotFoundError extends AppError {
  constructor(message = 'Not found') {
    super(message, 404, 'not_found');
  }
}

export class ConflictError extends AppError {
  constructor(message = 'Conflict') {
    super(message, 409, 'conflict');
  }
}

/** Raised when an action requires human approval before it can proceed. */
export class ApprovalRequiredError extends AppError {
  constructor(message = 'This action requires approval', details?: unknown) {
    super(message, 428, 'approval_required', details);
  }
}

export function isAppError(err: unknown): err is AppError {
  return err instanceof AppError;
}
