import type { Role } from './types.js';

/** Numeric rank, higher = more privileged. Used for comparisons. */
export const ROLE_RANK: Record<Role, number> = {
  owner: 100,
  super_admin: 80,
  admin: 60,
  editor: 40,
  user: 20,
  guest: 0,
};

export const ALL_ROLES: Role[] = ['owner', 'super_admin', 'admin', 'editor', 'user', 'guest'];

export function isAtLeast(role: Role, minimum: Role): boolean {
  return ROLE_RANK[role] >= ROLE_RANK[minimum];
}

/** Roles that may reach the Admin Panel at all. */
export function canAccessAdmin(role: Role): boolean {
  return isAtLeast(role, 'admin');
}
