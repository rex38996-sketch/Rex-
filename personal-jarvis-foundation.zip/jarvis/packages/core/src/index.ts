/**
 * @jarvis/core - shared domain types and pure business rules.
 *
 * This package must stay free of framework, database and provider
 * dependencies. Everything here is portable and unit-testable in isolation,
 * which is what lets the database implementation evolve without breaking
 * agent logic (blueprint section 52).
 */

export * from './types.js';
export * from './roles.js';
export * from './permissions.js';
export * from './errors.js';
