# Personal JARVIS

A private, modular, **provider-independent** personal AI assistant platform — an
AI operating system rather than a chatbot. Every major subsystem is designed to
be controlled from an Admin Panel, and no AI provider is hard-coded into the
application.

> This repository is the **Phase 1 foundation**. It implements the project
> structure, the architecture, the full database schema, and a running,
> tested core: authentication, the AI abstraction layer, model routing and
> failover, conversations, chat orchestration, and the first Admin Panel
> endpoints. Later phases build on top without reworking the foundation.

---

## Why it is structured this way

The blueprint's core rule is that subsystems must be swappable without breaking
each other:

- **AI provider can change** without breaking memory, tools or UI.
- **Model can change** without breaking the app.
- **Tool can change** without breaking chat.
- **UI can change** without breaking the backend.
- **Database implementation can evolve** without breaking agent logic.

Each of those is enforced by a boundary in the code:

| Guarantee | Enforced by |
| --- | --- |
| Provider independence | `packages/ai-adapter` — the only place a vendor is touched |
| Model independence | `ModelRouter` reads models from the database, not code |
| Tool independence | Tool registry + `toolIds` on each agent (Phase 5) |
| UI independence | `apps/web` talks only to the HTTP API |
| Database independence | `Repository` interface with in-memory and Prisma implementations |

## Repository layout

```
personal-jarvis/
├── packages/
│   ├── core/               # Shared domain types + pure rules (roles, permissions)
│   └── ai-adapter/         # Provider-independent AI layer: registry, router, adapters
├── apps/
│   ├── api/                # Backend: auth, chat orchestration, admin API
│   └── web/                # Next.js frontend (chat + admin shell)
├── prisma/
│   └── schema.prisma       # Full database schema (Postgres + pgvector)
├── docs/                   # Architecture, database, admin, provider guides
└── tests/                  # Vitest suite (unit + end-to-end API)
```

## Quick start

```bash
# 1. Install
npm install

# 2. Copy environment template (no secrets are required to run locally)
cp .env.example .env

# 3. Run the API (uses the built-in mock provider by default)
npm run start:api        # http://localhost:8787

# 4. In another terminal, run the web app
npm run dev --workspace @jarvis/web   # http://localhost:3000
```

The first account you register becomes the **Owner**. There are no credentials
seeded on purpose — the system starts empty and secure.

### Try it without a UI

```bash
# Register the owner and capture the token
curl -s localhost:8787/api/auth/register \
  -H 'content-type: application/json' \
  -d '{"email":"owner@jarvis.local","password":"supersecret","displayName":"Owner"}'

# Create a conversation
curl -s localhost:8787/api/chat/conversations -X POST \
  -H "authorization: Bearer <TOKEN>" -H 'content-type: application/json' -d '{}'

# Send a message
curl -s localhost:8787/api/chat/conversations/<ID>/messages -X POST \
  -H "authorization: Bearer <TOKEN>" -H 'content-type: application/json' \
  -d '{"content":"Explain motivation","mode":"deep_research"}'
```

## Commands

| Command | Purpose |
| --- | --- |
| `npm run start:api` | Run the API server |
| `npm run dev:api` | Run the API with watch/reload |
| `npm test` | Run the full Vitest suite |
| `npm run typecheck` | Type-check every workspace |
| `npm run db:validate` | Validate the Prisma schema |
| `npm run db:generate` | Generate the Prisma client (Phase 2) |

## Testing

The suite covers the permission engine, the AI adapter (registry, routing,
streaming, failover) and an end-to-end API flow (auth, chat, admin access
control). It runs against the in-memory store with the mock provider, so it
needs no database, network or API keys.

## Environment

All configuration is server-side and read from the environment (see
`.env.example`). Provider API keys are read only by the API process and are
never sent to the browser. In production, `SESSION_SECRET` is required.

## What is implemented vs. planned

Implemented in this foundation:

- Monorepo, TypeScript project references, workspaces
- Full database schema (users, sessions, conversations, messages, agents,
  agent versions, models, providers, credentials, memories, knowledge bases,
  documents, chunks, embeddings, tools, workflows, tasks, scheduled tasks,
  approvals, activity/audit logs, settings, themes, notifications, backups)
- Provider-independent AI layer with a registry, routing and failover
- Mock provider (zero-credential dev/test) and OpenAI-compatible provider
- Authentication: scrypt passwords, hashed session tokens, role-based access
- Chat orchestration: conversations, messages, auto-titling, activity logging
- Admin API: providers, models, agents, stats, activity and audit logs
- Next.js chat surface and Admin Panel shell
- Vitest suite (29 tests) + typecheck + schema validation

Planned phases (see `ROADMAP.md`): Prisma-backed persistence, memory engine,
knowledge/vector pipeline, tool system, custom agent builder, automation and
scheduling, voice, browser/computer agents, and the full Admin Panel.

## License

Private / unpublished.
