import { describe, expect, it } from 'vitest';
import {
  createDefaultRegistry,
  chatWithFallback,
  ModelRouter,
  type AIProvider,
  type ChatRequest,
} from '@jarvis/ai-adapter';
import type { ModelConfig } from '@jarvis/core';

const mockConfig = {
  id: 'p1',
  kind: 'mock',
  label: 'Mock',
  baseUrl: 'mock://local',
  apiKey: '',
  enabled: true,
  priority: 1,
};

function model(over: Partial<ModelConfig>): ModelConfig {
  return {
    id: 'm1',
    providerId: 'p1',
    name: 'M',
    modelKey: 'mock-fast',
    capabilities: ['fast'],
    contextWindow: 8192,
    costPer1kInput: 0,
    costPer1kOutput: 0,
    priority: 0,
    isDefault: false,
    enabled: true,
    ...over,
  };
}

describe('provider registry', () => {
  it('registers built-in adapter kinds', () => {
    const registry = createDefaultRegistry();
    expect(registry.hasKind('mock')).toBe(true);
    expect(registry.hasKind('openai_compatible')).toBe(true);
  });

  it('instantiates a provider from config', async () => {
    const registry = createDefaultRegistry();
    const provider = registry.add(mockConfig);
    const health = await provider.healthCheck();
    expect(health.ok).toBe(true);
  });

  it('rejects unknown provider kinds', () => {
    const registry = createDefaultRegistry();
    expect(() => registry.add({ ...mockConfig, kind: 'nope' })).toThrow(/Unknown provider kind/);
  });
});

describe('mock provider', () => {
  it('produces a deterministic reply with usage', async () => {
    const registry = createDefaultRegistry();
    const provider = registry.add(mockConfig);
    const res = await provider.chat({
      model: 'mock-fast',
      messages: [{ role: 'user', content: 'hello world' }],
    });
    expect(res.content).toContain('hello world');
    expect(res.usage.totalTokens).toBeGreaterThan(0);
    expect(res.finishReason).toBe('stop');
  });

  it('streams deltas then a done event', async () => {
    const registry = createDefaultRegistry();
    const provider = registry.add(mockConfig);
    const events: string[] = [];
    for await (const ev of provider.chatStream({
      model: 'mock-fast',
      messages: [{ role: 'user', content: 'stream me' }],
    })) {
      events.push(ev.type);
    }
    expect(events).toContain('delta');
    expect(events.at(-1)).toBe('done');
  });

  it('returns deterministic normalized embeddings', async () => {
    const registry = createDefaultRegistry();
    const provider = registry.add(mockConfig);
    const { embeddings } = await provider.embed({ model: 'mock-embed', input: ['alpha beta'] });
    expect(embeddings).toHaveLength(1);
    const norm = Math.sqrt(embeddings[0]!.reduce((s, v) => s + v * v, 0));
    expect(norm).toBeCloseTo(1, 5);
  });
});

describe('model router', () => {
  it('routes a coding task to the coding model', () => {
    const router = new ModelRouter([
      model({ id: 'fast', name: 'Fast', capabilities: ['fast', 'cheap'], priority: 10 }),
      model({ id: 'coder', name: 'Coder', capabilities: ['coding'], priority: 1 }),
    ]);
    const decision = router.route({ needs: ['coding'] });
    expect(decision.model.id).toBe('coder');
  });

  it('honours a manual model override', () => {
    const router = new ModelRouter([model({ id: 'fast', capabilities: ['fast'] })]);
    const decision = router.route({ needs: [], forceModelId: 'fast' });
    expect(decision.reason).toBe('manual selection');
  });

  it('throws when no enabled model satisfies the need', () => {
    const router = new ModelRouter([model({ id: 'fast', capabilities: ['fast'] })]);
    expect(() => router.route({ needs: ['vision'] })).toThrow(/No enabled model/);
  });
});

describe('failover', () => {
  it('falls through to the next provider when the first fails', async () => {
    const failing: AIProvider = {
      id: 'bad',
      kind: 'x',
      label: 'bad',
      chat: async () => {
        throw new Error('boom');
      },
      chatStream: async function* () {},
      embed: async () => ({ embeddings: [], model: '', usage: { inputTokens: 0, outputTokens: 0, totalTokens: 0 } }),
      listModels: async () => [],
      healthCheck: async () => ({ ok: false, latencyMs: 0 }),
    };
    const registry = createDefaultRegistry();
    const good = registry.add(mockConfig);
    const req: ChatRequest = { model: 'mock-fast', messages: [{ role: 'user', content: 'hi' }] };
    const result = await chatWithFallback(req, [failing, good]);
    expect(result.providerId).toBe('p1');
    expect(result.attempts).toEqual(['bad', 'p1']);
  });
});
