import { describe, expect, it } from 'vitest';
import {
  checkAgentPermission,
  DEFAULT_AGENT_PERMISSIONS,
  isAtLeast,
  resolvePermissionLevel,
  roleCan,
} from '@jarvis/core';

describe('roles', () => {
  it('ranks owner above admin above user above guest', () => {
    expect(isAtLeast('owner', 'admin')).toBe(true);
    expect(isAtLeast('admin', 'owner')).toBe(false);
    expect(isAtLeast('user', 'guest')).toBe(true);
  });

  it('reserves delete/configure for admins', () => {
    expect(roleCan('admin', 'delete')).toBe(true);
    expect(roleCan('editor', 'delete')).toBe(false);
    expect(roleCan('user', 'configure')).toBe(false);
  });
});

describe('permission engine', () => {
  it('never lets a user exceed their role', () => {
    // A guest cannot execute even if the policy says allowed.
    expect(resolvePermissionLevel('allowed', 'guest', 'execute')).toBe('blocked');
  });

  it('preserves approval_required for the approval system to gate', () => {
    expect(resolvePermissionLevel('approval_required', 'admin', 'execute')).toBe('approval_required');
  });

  it('lets blocked always win', () => {
    expect(resolvePermissionLevel('blocked', 'owner', 'execute')).toBe('blocked');
  });

  it('blocks a purchase for a normal user but allows an owner', () => {
    const perms = { ...DEFAULT_AGENT_PERMISSIONS, purchase: 'approval_required' as const };
    expect(checkAgentPermission(perms, 'purchase', 'user')).toBe('approval_required');
    expect(checkAgentPermission(perms, 'purchase', 'owner')).toBe('approval_required');
    expect(checkAgentPermission(DEFAULT_AGENT_PERMISSIONS, 'delete', 'user')).toBe('blocked');
  });
});
