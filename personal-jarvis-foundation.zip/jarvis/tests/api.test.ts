import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import type { Server } from 'node:http';
import { bootstrap } from '../apps/api/src/bootstrap.js';
import { createServer } from '../apps/api/src/server.js';
import { loadConfig } from '../apps/api/src/config.js';

let server: Server;
let baseUrl: string;

async function api(path: string, init: RequestInit = {}, token?: string) {
  const res = await fetch(`${baseUrl}${path}`, {
    ...init,
    headers: {
      'content-type': 'application/json',
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...init.headers,
    },
  });
  const body: any = await res.json().catch(() => ({}));
  return { status: res.status, body };
}

beforeAll(async () => {
  const config = loadConfig({
    NODE_ENV: 'test',
    SESSION_SECRET: 'test-secret-abcdefghij',
    PORT: '0',
  } as NodeJS.ProcessEnv);
  const container = await bootstrap(config);
  const app = createServer(container);
  await new Promise<void>((resolve) => {
    server = app.listen(0, () => resolve());
  });
  const addr = server.address();
  const port = typeof addr === 'object' && addr ? addr.port : 0;
  baseUrl = `http://127.0.0.1:${port}`;
});

afterAll(async () => {
  await new Promise<void>((resolve) => server.close(() => resolve()));
});

describe('health', () => {
  it('reports ok', async () => {
    const { status, body } = await api('/health');
    expect(status).toBe(200);
    expect(body.ok).toBe(true);
  });
});

describe('auth flow', () => {
  let token = '';

  it('registers the first user as owner', async () => {
    const { status, body } = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email: 'owner@jarvis.local', password: 'supersecret', displayName: 'Owner' }),
    });
    expect(status).toBe(201);
    expect(body.user.role).toBe('owner');
    expect(body.user.passwordHash).toBeUndefined();
    expect(typeof body.token).toBe('string');
    token = body.token;
  });

  it('registers subsequent users as plain users', async () => {
    const { body } = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email: 'user@jarvis.local', password: 'supersecret', displayName: 'User' }),
    });
    expect(body.user.role).toBe('user');
  });

  it('rejects a duplicate email', async () => {
    const { status } = await api('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify({ email: 'owner@jarvis.local', password: 'supersecret', displayName: 'Dup' }),
    });
    expect(status).toBe(409);
  });

  it('rejects a bad password', async () => {
    const { status } = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'owner@jarvis.local', password: 'wrong' }),
    });
    expect(status).toBe(401);
  });

  it('logs in and returns the current user', async () => {
    const login = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'owner@jarvis.local', password: 'supersecret' }),
    });
    expect(login.status).toBe(200);
    const me = await api('/api/auth/me', {}, login.body.token);
    expect(me.body.user.email).toBe('owner@jarvis.local');
  });

  it('blocks unauthenticated access to chat', async () => {
    const { status } = await api('/api/chat/conversations');
    expect(status).toBe(401);
  });
});

describe('chat orchestration', () => {
  let token = '';

  beforeAll(async () => {
    const login = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'owner@jarvis.local', password: 'supersecret' }),
    });
    token = login.body.token;
  });

  it('creates a conversation, sends a message and gets a routed reply', async () => {
    const created = await api('/api/chat/conversations', { method: 'POST', body: '{}' }, token);
    expect(created.status).toBe(201);
    const id = created.body.conversation.id as string;

    const sent = await api(
      `/api/chat/conversations/${id}/messages`,
      { method: 'POST', body: JSON.stringify({ content: 'Explain motivation', mode: 'chat' }) },
      token,
    );
    expect(sent.status).toBe(201);
    expect(sent.body.assistantMessage.content).toContain('Explain motivation');
    expect(sent.body.routing.modelId).toBeTruthy();
    expect(sent.body.usage.outputTokens).toBeGreaterThan(0);

    const messages = await api(`/api/chat/conversations/${id}/messages`, {}, token);
    expect(messages.body.messages).toHaveLength(2);
    expect(messages.body.messages[0].role).toBe('user');
    expect(messages.body.messages[1].role).toBe('assistant');
  });

  it('routes a deep_research task to a research-capable model', async () => {
    const created = await api('/api/chat/conversations', { method: 'POST', body: '{}' }, token);
    const id = created.body.conversation.id as string;
    const sent = await api(
      `/api/chat/conversations/${id}/messages`,
      { method: 'POST', body: JSON.stringify({ content: 'Deep dive', mode: 'deep_research' }) },
      token,
    );
    expect(sent.body.routing.modelName).toBe('Mock Reasoning');
  });

  it('enforces conversation ownership', async () => {
    const login = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email: 'user@jarvis.local', password: 'supersecret' }),
    });
    const created = await api('/api/chat/conversations', { method: 'POST', body: '{}' }, token);
    const other = await api(
      `/api/chat/conversations/${created.body.conversation.id}`,
      {},
      login.body.token,
    );
    expect(other.status).toBe(403);
  });
});

describe('admin panel', () => {
  let ownerToken = '';
  let userToken = '';

  beforeAll(async () => {
    ownerToken = (
      await api('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: 'owner@jarvis.local', password: 'supersecret' }),
      })
    ).body.token;
    userToken = (
      await api('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: 'user@jarvis.local', password: 'supersecret' }),
      })
    ).body.token;
  });

  it('denies a normal user access to admin routes', async () => {
    const { status } = await api('/api/admin/stats', {}, userToken);
    expect(status).toBe(403);
  });

  it('lets an owner read stats and providers without leaking secrets', async () => {
    const stats = await api('/api/admin/stats', {}, ownerToken);
    expect(stats.status).toBe(200);
    expect(stats.body.stats.models).toBeGreaterThan(0);

    const providers = await api('/api/admin/providers', {}, ownerToken);
    expect(providers.status).toBe(200);
    for (const p of providers.body.providers) {
      expect(p.secret).toBeUndefined();
      expect(typeof p.hasSecret).toBe('boolean');
    }
  });

  it('records an audit entry when an admin creates a model', async () => {
    const providers = await api('/api/admin/providers', {}, ownerToken);
    const providerId = providers.body.providers[0].id;
    const created = await api(
      '/api/admin/models',
      {
        method: 'POST',
        body: JSON.stringify({
          providerId,
          name: 'Vision Model',
          modelKey: 'mock-vision',
          capabilities: ['vision'],
          contextWindow: 16000,
        }),
      },
      ownerToken,
    );
    expect(created.status).toBe(201);

    const audit = await api('/api/admin/audit', {}, ownerToken);
    expect(audit.body.audit.some((e: { event: string }) => e.event === 'model.created')).toBe(true);
  });
});

describe('CORS (cloud / cross-origin)', () => {
  it('answers a preflight request with permissive headers in non-production', async () => {
    const res = await fetch(`${baseUrl}/api/auth/login`, {
      method: 'OPTIONS',
      headers: { origin: 'https://example-codespace-3000.app.github.dev' },
    });
    expect(res.status).toBe(204);
    expect(res.headers.get('access-control-allow-origin')).toBe(
      'https://example-codespace-3000.app.github.dev',
    );
    expect(res.headers.get('access-control-allow-headers')).toContain('authorization');
  });

  it('adds an allow-origin header to a normal cross-origin request', async () => {
    const res = await fetch(`${baseUrl}/health`, {
      headers: { origin: 'https://example-codespace-3000.app.github.dev' },
    });
    expect(res.status).toBe(200);
    expect(res.headers.get('access-control-allow-origin')).toBe(
      'https://example-codespace-3000.app.github.dev',
    );
  });
});
