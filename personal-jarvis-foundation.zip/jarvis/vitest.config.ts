import { defineConfig } from 'vitest/config';
import { fileURLToPath } from 'node:url';

const r = (p: string) => fileURLToPath(new URL(p, import.meta.url));

export default defineConfig({
  test: {
    environment: 'node',
    include: ['tests/**/*.test.ts'],
    // Single fork keeps memory low in constrained environments.
    pool: 'forks',
    poolOptions: { forks: { singleFork: true } },
    testTimeout: 20000,
  },
  resolve: {
    alias: {
      '@jarvis/core': r('./packages/core/src/index.ts'),
      '@jarvis/ai-adapter': r('./packages/ai-adapter/src/index.ts'),
    },
  },
});
