import type { AppConfig } from './config.js';
import type { Store } from './db/store.js';
import type { AuthService } from './auth/authService.js';
import type { AIService } from './services/aiService.js';
import type { ChatService } from './services/chatService.js';
import type { LogService } from './services/logService.js';

/**
 * Composition root. Everything a request handler needs is wired here once,
 * which keeps routes thin and makes the whole graph trivially mockable in
 * tests.
 */
export interface Container {
  config: AppConfig;
  store: Store;
  auth: AuthService;
  ai: AIService;
  chat: ChatService;
  logs: LogService;
}
