import express, { type Express } from 'express';
import type { Container } from './container.js';
import { attachUser } from './middleware/auth.js';
import { corsMiddleware } from './middleware/cors.js';
import { errorHandler, notFoundHandler } from './middleware/errorHandler.js';
import { authRoutes } from './routes/auth.js';
import { chatRoutes } from './routes/chat.js';
import { adminRoutes } from './routes/admin.js';

/** Build the Express application around a fully-wired container. */
export function createServer(container: Container): Express {
  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', true);
  app.use(corsMiddleware(container.config));
  app.use(express.json({ limit: '2mb' }));
  app.use(attachUser(container));

  app.get('/health', (_req, res) => {
    res.json({ ok: true, env: container.config.env, version: '0.1.0' });
  });

  app.use('/api/auth', authRoutes(container));
  app.use('/api/chat', chatRoutes(container));
  app.use('/api/admin', adminRoutes(container));

  app.use(notFoundHandler());
  app.use(errorHandler());
  return app;
}
