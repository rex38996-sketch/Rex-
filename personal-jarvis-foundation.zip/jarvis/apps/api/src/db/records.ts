import type {
  Agent,
  AgentPermissions,
  ApprovalStatus,
  Capability,
  Citation,
  ConversationStatus,
  DocumentStatus,
  ISODateString,
  MemoryKind,
  MessageRole,
  PermissionLevel,
  Role,
} from '@jarvis/core';

/**
 * Persistence records. These are intentionally flat and storage-agnostic;
 * they map 1:1 to the Prisma models but carry no ORM coupling.
 */

export interface UserRecord {
  id: string;
  email: string;
  displayName: string;
  role: Role;
  passwordHash: string;
  disabled: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface SessionRecord {
  id: string;
  userId: string;
  tokenHash: string;
  userAgent?: string;
  ip?: string;
  createdAt: ISODateString;
  expiresAt: ISODateString;
  revokedAt: ISODateString | null;
}

export interface ConversationRecord {
  id: string;
  userId: string;
  title: string;
  folderId: string | null;
  status: ConversationStatus;
  pinned: boolean;
  agentId: string | null;
  modelId: string | null;
  useMemory: boolean;
  useKnowledge: boolean;
  useWeb: boolean;
  useTools: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface MessageRecord {
  id: string;
  conversationId: string;
  role: MessageRole;
  content: string;
  modelId: string | null;
  agentId: string | null;
  citations: Citation[];
  tokenInput: number | null;
  tokenOutput: number | null;
  createdAt: ISODateString;
}

export interface AgentRecord extends Omit<Agent, 'allowedActions' | 'toolIds'> {
  allowedActions: Agent['allowedActions'];
  toolIds: string[];
  permissions: AgentPermissions;
}

export interface ModelRecord {
  id: string;
  providerId: string;
  name: string;
  modelKey: string;
  capabilities: Capability[];
  contextWindow: number;
  costPer1kInput: number;
  costPer1kOutput: number;
  priority: number;
  isDefault: boolean;
  enabled: boolean;
}

export interface ProviderRecord {
  id: string;
  kind: string;
  label: string;
  baseUrl: string;
  /** Ciphertext in production; plaintext only in dev/test. Never serialised out. */
  secret: string;
  headers: Record<string, string>;
  timeoutMs: number;
  enabled: boolean;
  priority: number;
}

export interface MemoryRecord {
  id: string;
  userId: string | null;
  agentId: string | null;
  kind: MemoryKind;
  content: string;
  category: string | null;
  importance: number;
  confidence: number;
  source: string | null;
  pinned: boolean;
  locked: boolean;
  approved: boolean;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface KnowledgeBaseRecord {
  id: string;
  name: string;
  description: string;
  ownerId: string;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface DocumentRecord {
  id: string;
  knowledgeBaseId: string;
  title: string;
  mimeType: string;
  sizeBytes: number;
  storageKey: string;
  version: number;
  status: DocumentStatus;
  error: string | null;
  pageCount: number | null;
  createdAt: ISODateString;
  updatedAt: ISODateString;
}

export interface ActivityLogRecord {
  id: string;
  userId: string | null;
  agentId: string | null;
  modelId: string | null;
  toolId: string | null;
  action: string;
  input: unknown;
  output: unknown;
  status: string;
  error: string | null;
  durationMs: number | null;
  createdAt: ISODateString;
}

export interface AuditLogRecord {
  id: string;
  actorId: string | null;
  event: string;
  target: string | null;
  before: unknown;
  after: unknown;
  createdAt: ISODateString;
}

export interface SettingRecord {
  id: string;
  value: unknown;
  updatedAt: ISODateString;
}

export type { ApprovalStatus, PermissionLevel };
