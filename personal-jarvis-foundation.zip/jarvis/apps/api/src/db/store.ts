import { randomUUID } from 'node:crypto';
import type {
  ActivityLogRecord,
  AgentRecord,
  AuditLogRecord,
  ConversationRecord,
  DocumentRecord,
  KnowledgeBaseRecord,
  MemoryRecord,
  MessageRecord,
  ModelRecord,
  ProviderRecord,
  SessionRecord,
  SettingRecord,
  UserRecord,
} from './records.js';

/**
 * Repository abstraction. Phase 1 ships an in-memory implementation so the
 * whole platform is runnable and testable with zero infrastructure. Phase 2
 * adds a Prisma-backed implementation of the *same* interface, so agent logic
 * never changes when the database does (blueprint section 52).
 */
export interface Repository<T extends { id: string }> {
  create(entity: Omit<T, 'id'> & Partial<Pick<T, 'id'>>): Promise<T>;
  get(id: string): Promise<T | undefined>;
  list(filter?: (entity: T) => boolean): Promise<T[]>;
  findOne(predicate: (entity: T) => boolean): Promise<T | undefined>;
  update(id: string, patch: Partial<T>): Promise<T | undefined>;
  delete(id: string): Promise<boolean>;
  count(filter?: (entity: T) => boolean): Promise<number>;
}

export class InMemoryRepository<T extends { id: string }> implements Repository<T> {
  private readonly rows = new Map<string, T>();

  constructor(private readonly clone = true) {}

  private copy(entity: T): T {
    return this.clone ? structuredClone(entity) : entity;
  }

  async create(entity: Omit<T, 'id'> & Partial<Pick<T, 'id'>>): Promise<T> {
    const row = { ...entity, id: (entity as { id?: string }).id ?? randomUUID() } as T;
    this.rows.set(row.id, row);
    return this.copy(row);
  }

  async get(id: string): Promise<T | undefined> {
    const row = this.rows.get(id);
    return row ? this.copy(row) : undefined;
  }

  async list(filter?: (entity: T) => boolean): Promise<T[]> {
    const all = [...this.rows.values()];
    const selected = filter ? all.filter(filter) : all;
    return selected.map((r) => this.copy(r));
  }

  async findOne(predicate: (entity: T) => boolean): Promise<T | undefined> {
    for (const row of this.rows.values()) if (predicate(row)) return this.copy(row);
    return undefined;
  }

  async update(id: string, patch: Partial<T>): Promise<T | undefined> {
    const row = this.rows.get(id);
    if (!row) return undefined;
    const updated = { ...row, ...patch, id: row.id } as T;
    this.rows.set(id, updated);
    return this.copy(updated);
  }

  async delete(id: string): Promise<boolean> {
    return this.rows.delete(id);
  }

  async count(filter?: (entity: T) => boolean): Promise<number> {
    if (!filter) return this.rows.size;
    return [...this.rows.values()].filter(filter).length;
  }
}

/** The aggregate data-access surface used by services. */
export interface Store {
  users: Repository<UserRecord>;
  sessions: Repository<SessionRecord>;
  conversations: Repository<ConversationRecord>;
  messages: Repository<MessageRecord>;
  agents: Repository<AgentRecord>;
  models: Repository<ModelRecord>;
  providers: Repository<ProviderRecord>;
  memories: Repository<MemoryRecord>;
  knowledgeBases: Repository<KnowledgeBaseRecord>;
  documents: Repository<DocumentRecord>;
  activityLogs: Repository<ActivityLogRecord>;
  auditLogs: Repository<AuditLogRecord>;
  settings: Repository<SettingRecord>;
}

export function createInMemoryStore(): Store {
  return {
    users: new InMemoryRepository<UserRecord>(),
    sessions: new InMemoryRepository<SessionRecord>(),
    conversations: new InMemoryRepository<ConversationRecord>(),
    messages: new InMemoryRepository<MessageRecord>(),
    agents: new InMemoryRepository<AgentRecord>(),
    models: new InMemoryRepository<ModelRecord>(),
    providers: new InMemoryRepository<ProviderRecord>(),
    memories: new InMemoryRepository<MemoryRecord>(),
    knowledgeBases: new InMemoryRepository<KnowledgeBaseRecord>(),
    documents: new InMemoryRepository<DocumentRecord>(),
    activityLogs: new InMemoryRepository<ActivityLogRecord>(),
    auditLogs: new InMemoryRepository<AuditLogRecord>(),
    settings: new InMemoryRepository<SettingRecord>(),
  };
}
