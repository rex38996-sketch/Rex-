import { createHash, randomBytes, scryptSync, timingSafeEqual } from 'node:crypto';

/**
 * Password and token primitives. Passwords use scrypt with a per-user salt;
 * session tokens are stored only as SHA-256 hashes so a database leak does not
 * expose live sessions (blueprint section 40).
 */

const SCRYPT_KEYLEN = 64;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString('hex');
  const derived = scryptSync(password, salt, SCRYPT_KEYLEN).toString('hex');
  return `scrypt$${salt}$${derived}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [scheme, salt, digest] = stored.split('$');
  if (scheme !== 'scrypt' || !salt || !digest) return false;
  const derived = scryptSync(password, salt, SCRYPT_KEYLEN);
  const expected = Buffer.from(digest, 'hex');
  if (derived.length !== expected.length) return false;
  return timingSafeEqual(derived, expected);
}

/** Generate a high-entropy opaque session token (returned to the client). */
export function generateToken(): string {
  return randomBytes(32).toString('base64url');
}

/** One-way hash used to store tokens at rest. */
export function hashToken(token: string): string {
  return createHash('sha256').update(token).digest('hex');
}
