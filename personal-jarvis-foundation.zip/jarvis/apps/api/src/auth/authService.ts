import { randomUUID } from 'node:crypto';
import { UnauthorizedError, ConflictError, type PublicUser, type Role } from '@jarvis/core';
import type { Store } from '../db/store.js';
import type { SessionRecord, UserRecord } from '../db/records.js';
import { generateToken, hashPassword, hashToken, verifyPassword } from './passwords.js';

export interface AuthServiceOptions {
  sessionTtlHours: number;
}

export function toPublicUser(user: UserRecord): PublicUser {
  const { passwordHash: _omit, ...rest } = user;
  return rest;
}

export class AuthService {
  constructor(
    private readonly store: Store,
    private readonly options: AuthServiceOptions,
  ) {}

  async register(input: {
    email: string;
    password: string;
    displayName: string;
    role?: Role;
  }): Promise<PublicUser> {
    const email = input.email.trim().toLowerCase();
    const existing = await this.store.users.findOne((u) => u.email === email);
    if (existing) throw new ConflictError('An account with that email already exists');
    const now = new Date().toISOString();
    const user = await this.store.users.create({
      email,
      displayName: input.displayName,
      role: input.role ?? 'user',
      passwordHash: hashPassword(input.password),
      disabled: false,
      createdAt: now,
      updatedAt: now,
    });
    return toPublicUser(user);
  }

  async authenticate(email: string, password: string): Promise<UserRecord> {
    const user = await this.store.users.findOne((u) => u.email === email.trim().toLowerCase());
    if (!user || user.disabled) throw new UnauthorizedError('Invalid credentials');
    if (!verifyPassword(password, user.passwordHash)) throw new UnauthorizedError('Invalid credentials');
    return user;
  }

  async createSession(
    userId: string,
    meta: { userAgent?: string; ip?: string } = {},
  ): Promise<{ token: string; session: SessionRecord }> {
    const token = generateToken();
    const now = Date.now();
    const session = await this.store.sessions.create({
      userId,
      tokenHash: hashToken(token),
      userAgent: meta.userAgent,
      ip: meta.ip,
      createdAt: new Date(now).toISOString(),
      expiresAt: new Date(now + this.options.sessionTtlHours * 3600_000).toISOString(),
      revokedAt: null,
    });
    return { token, session };
  }

  /** Resolve a bearer token to its (non-disabled) user, or throw. */
  async resolveSession(token: string): Promise<{ user: UserRecord; session: SessionRecord }> {
    const session = await this.store.sessions.findOne((s) => s.tokenHash === hashToken(token));
    if (!session) throw new UnauthorizedError('Session not found');
    if (session.revokedAt) throw new UnauthorizedError('Session revoked');
    if (Date.parse(session.expiresAt) < Date.now()) throw new UnauthorizedError('Session expired');
    const user = await this.store.users.get(session.userId);
    if (!user || user.disabled) throw new UnauthorizedError('Account unavailable');
    return { user, session };
  }

  async revokeSession(token: string): Promise<void> {
    const session = await this.store.sessions.findOne((s) => s.tokenHash === hashToken(token));
    if (!session) return;
    await this.store.sessions.update(session.id, { revokedAt: new Date().toISOString() });
  }

  /** Helper used by the bootstrap seeder. */
  static newId(): string {
    return randomUUID();
  }
}
