import { loadConfig, type AppConfig } from './config.js';
import type { Container } from './container.js';
import { createInMemoryStore } from './db/store.js';
import { AuthService } from './auth/authService.js';
import { AIService } from './services/aiService.js';
import { ChatService } from './services/chatService.js';
import { LogService } from './services/logService.js';

/**
 * Seed a usable default environment: one mock provider, two routable models,
 * and a built-in Personal Assistant agent. In production the same records are
 * created through the Admin Panel; here they make the platform usable and
 * testable immediately.
 */
export async function bootstrap(config: AppConfig = loadConfig()): Promise<Container> {
  const store = createInMemoryStore();
  const logs = new LogService(store);
  const auth = new AuthService(store, { sessionTtlHours: config.sessionTtlHours });
  const ai = new AIService(store);

  const mockProvider = await store.providers.create({
    kind: 'mock',
    label: 'Built-in Mock',
    baseUrl: 'mock://local',
    secret: '',
    headers: {},
    timeoutMs: 30000,
    enabled: true,
    priority: 100,
  });

  await store.models.create({
    providerId: mockProvider.id,
    name: 'Mock Fast',
    modelKey: 'mock-fast',
    capabilities: ['fast', 'cheap'],
    contextWindow: 8192,
    costPer1kInput: 0,
    costPer1kOutput: 0,
    priority: 10,
    isDefault: true,
    enabled: true,
  });

  await store.models.create({
    providerId: mockProvider.id,
    name: 'Mock Reasoning',
    modelKey: 'mock-reasoning',
    capabilities: ['reasoning', 'research', 'long_context'],
    contextWindow: 32768,
    costPer1kInput: 0,
    costPer1kOutput: 0,
    priority: 5,
    isDefault: false,
    enabled: true,
  });

  // If a real OpenAI-compatible key is present, register it as a second
  // provider so routing and failover can be exercised against a live model.
  if (config.ai.apiKey) {
    const live = await store.providers.create({
      kind: 'openai_compatible',
      label: 'OpenAI-compatible',
      baseUrl: config.ai.baseUrl,
      secret: config.ai.apiKey,
      headers: {},
      timeoutMs: 60000,
      enabled: true,
      priority: 1,
    });
    await store.models.create({
      providerId: live.id,
      name: 'GPT-class Reasoning',
      modelKey: 'gpt-4o-mini',
      capabilities: ['reasoning', 'fast', 'coding'],
      contextWindow: 128000,
      costPer1kInput: 0.00015,
      costPer1kOutput: 0.0006,
      priority: 50,
      isDefault: false,
      enabled: true,
    });
  }

  const now = new Date().toISOString();
  await store.agents.create({
    name: 'Personal Assistant',
    description: 'General-purpose assistant with memory, knowledge and tools.',
    avatar: null,
    personality: 'Warm, concise, proactive.',
    systemPrompt: 'You are JARVIS, a helpful personal AI assistant. Be concise and accurate.',
    modelId: null,
    temperature: 0.7,
    memoryAccess: true,
    knowledgeAccess: true,
    webAccess: false,
    fileAccess: true,
    browserAccess: false,
    computerAccess: false,
    toolIds: [],
    allowedActions: ['view', 'use'],
    restrictions: [],
    responseStyle: 'balanced',
    language: 'en',
    outputFormat: 'markdown',
    permissions: {
      browserRead: 'allowed',
      browserClick: 'allowed',
      browserType: 'approval_required',
      computerControl: 'approval_required',
      purchase: 'approval_required',
      delete: 'blocked',
      sendMessage: 'approval_required',
      changeSettings: 'approval_required',
      runCommand: 'approval_required',
    },
    version: 1,
    isBuiltIn: true,
    createdAt: now,
    updatedAt: now,
  } as never);

  const chat = new ChatService(store, ai, logs);
  await ai.sync();

  return { config, store, auth, ai, chat, logs };
}
