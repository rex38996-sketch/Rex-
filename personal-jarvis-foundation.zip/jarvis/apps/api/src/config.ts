import { randomBytes } from 'node:crypto';

/**
 * CORS_ORIGINS may be a comma-separated allowlist, or "*" for any origin.
 * When unset, non-production defaults to "*" (dev convenience) and production
 * defaults to a locked-down empty list.
 */
function parseCorsOrigins(raw: string | undefined, nodeEnv: AppConfig['env']): string[] | '*' {
  if (raw && raw.trim()) {
    const value = raw.trim();
    if (value === '*') return '*';
    return value
      .split(',')
      .map((o) => o.trim())
      .filter(Boolean);
  }
  return nodeEnv === 'production' ? [] : '*';
}

/**
 * Runtime configuration, read once at boot. Secrets stay server-side; this
 * object is never serialised to the client (blueprint sections 11 & 40).
 */
export interface AppConfig {
  env: 'development' | 'test' | 'production';
  port: number;
  sessionSecret: string;
  sessionTtlHours: number;
  /**
   * Allowed browser origins for the API. `'*'` reflects any origin (fine for
   * local dev and cloud dev containers); an explicit list locks it down in
   * production. Driven by the CORS_ORIGINS env var.
   */
  corsOrigins: string[] | '*';
  /** Provider configs assembled from environment for the default setup. */
  ai: {
    baseUrl: string;
    apiKey: string;
  };
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const nodeEnv = (env.NODE_ENV ?? 'development') as AppConfig['env'];
  const sessionSecret = env.SESSION_SECRET ?? '';
  if (nodeEnv === 'production' && sessionSecret.length < 16) {
    throw new Error('SESSION_SECRET must be set (>=16 chars) in production');
  }
  return {
    env: nodeEnv,
    port: Number(env.PORT ?? 8787),
    sessionSecret: sessionSecret || randomBytes(32).toString('hex'),
    sessionTtlHours: Number(env.SESSION_TTL_HOURS ?? 24 * 7),
    corsOrigins: parseCorsOrigins(env.CORS_ORIGINS, nodeEnv),
    ai: {
      baseUrl: env.AI_PROVIDER_OPENAI_COMPATIBLE_BASE_URL ?? 'https://api.openai.com/v1',
      apiKey: env.AI_PROVIDER_OPENAI_COMPATIBLE_API_KEY ?? '',
    },
  };
}
