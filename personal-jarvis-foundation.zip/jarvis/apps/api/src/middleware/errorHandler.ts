import type { NextFunction, Request, Response } from 'express';
import { ZodError } from 'zod';
import { AppError, isAppError } from '@jarvis/core';

/** Terminal error handler: maps typed errors to clean JSON responses. */
export function errorHandler() {
  return (err: unknown, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof ZodError) {
      return res.status(400).json({
        error: { code: 'validation_error', message: 'Invalid input', details: err.flatten() },
      });
    }
    if (isAppError(err)) {
      const appErr = err as AppError;
      return res.status(appErr.status).json({
        error: { code: appErr.code, message: appErr.message, details: appErr.details },
      });
    }
    const message = err instanceof Error ? err.message : 'Unexpected error';
    // eslint-disable-next-line no-console
    console.error('[unhandled]', err);
    return res.status(500).json({ error: { code: 'internal_error', message } });
  };
}

export function notFoundHandler() {
  return (_req: Request, res: Response) => {
    res.status(404).json({ error: { code: 'not_found', message: 'Route not found' } });
  };
}
