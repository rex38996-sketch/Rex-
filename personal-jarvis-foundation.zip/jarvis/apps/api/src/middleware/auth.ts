import type { NextFunction, Request, Response } from 'express';
import { ForbiddenError, UnauthorizedError, isAtLeast, type PublicUser, type Role } from '@jarvis/core';
import type { Container } from '../container.js';
import { toPublicUser } from '../auth/authService.js';

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      user?: PublicUser;
      sessionToken?: string;
    }
  }
}

function bearerToken(req: Request): string | null {
  const header = req.header('authorization');
  if (!header) return null;
  const [scheme, token] = header.split(' ');
  if (scheme?.toLowerCase() !== 'bearer' || !token) return null;
  return token;
}

/** Attaches req.user when a valid session is present; never throws on its own. */
export function attachUser(container: Container) {
  return async (req: Request, _res: Response, next: NextFunction) => {
    const token = bearerToken(req);
    if (!token) return next();
    try {
      const { user } = await container.auth.resolveSession(token);
      req.user = toPublicUser(user);
      req.sessionToken = token;
    } catch {
      // Leave unauthenticated; requireAuth will decide.
    }
    next();
  };
}

export function requireAuth() {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(new UnauthorizedError());
    next();
  };
}

export function requireRole(minimum: Role) {
  return (req: Request, _res: Response, next: NextFunction) => {
    if (!req.user) return next(new UnauthorizedError());
    if (!isAtLeast(req.user.role, minimum)) {
      return next(new ForbiddenError(`Requires role ${minimum} or higher`));
    }
    next();
  };
}
