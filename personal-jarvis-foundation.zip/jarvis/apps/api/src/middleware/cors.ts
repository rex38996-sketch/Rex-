import type { NextFunction, Request, Response } from 'express';
import type { AppConfig } from '../config.js';

/**
 * Minimal, dependency-free CORS middleware.
 *
 * Cloud dev containers (GitHub Codespaces, Replit, ...) serve the web app and
 * the API from two different origins, so the browser needs CORS headers before
 * it will let the frontend call the API. When `corsOrigins` is `'*'` we reflect
 * the caller's origin; otherwise only allowlisted origins get headers.
 *
 * This is safe with our auth model: we use a Bearer token (not cookies), so we
 * do not enable credentialed requests.
 */
export function corsMiddleware(config: AppConfig) {
  const allowed = config.corsOrigins;
  return (req: Request, res: Response, next: NextFunction) => {
    const origin = req.header('origin');
    const permitted = allowed === '*' || (origin !== undefined && allowed.includes(origin));
    if (permitted) {
      res.setHeader('Access-Control-Allow-Origin', allowed === '*' ? origin ?? '*' : origin!);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,PUT,DELETE,OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'content-type,authorization');
      res.setHeader('Access-Control-Max-Age', '86400');
    }
    if (req.method === 'OPTIONS') {
      res.sendStatus(204);
      return;
    }
    next();
  };
}
