import { bootstrap } from './bootstrap.js';
import { createServer } from './server.js';

async function main(): Promise<void> {
  const container = await bootstrap();
  const app = createServer(container);
  app.listen(container.config.port, () => {
    // eslint-disable-next-line no-console
    console.log(
      `Personal JARVIS API listening on http://localhost:${container.config.port} (${container.config.env})`,
    );
  });
}

main().catch((err) => {
  // eslint-disable-next-line no-console
  console.error('Fatal startup error:', err);
  process.exit(1);
});
