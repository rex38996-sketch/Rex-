import {
  chatWithFallback,
  createDefaultRegistry,
  ModelRouter,
  type AIProvider,
  type ChatMessage,
  type ChatRequest,
  type ChatResponse,
  type ProviderRegistry,
  type RoutingDecision,
  type TaskProfile,
} from '@jarvis/ai-adapter';
import type { Capability, ModelConfig } from '@jarvis/core';
import type { Store } from '../db/store.js';
import type { ProviderRecord } from '../db/records.js';

export interface ChatExecution {
  response: ChatResponse;
  decision: RoutingDecision;
  providerId: string;
  attempts: string[];
  durationMs: number;
}

/**
 * The AI Orchestrator (blueprint section 2). It owns the provider registry and
 * the model router, both of which are populated from Admin-Panel-managed data
 * in the database. Swapping a provider or model is a data change, never a code
 * change.
 */
export class AIService {
  readonly registry: ProviderRegistry;
  private router: ModelRouter;

  constructor(private readonly store: Store) {
    this.registry = createDefaultRegistry();
    this.router = new ModelRouter([]);
  }

  /** Rebuild provider instances and the routing table from persisted config. */
  async sync(): Promise<void> {
    const providers = await this.store.providers.list((p) => p.enabled);
    for (const provider of providers) {
      this.registry.add(toProviderConfig(provider));
    }
    const models = await this.store.models.list((m) => m.enabled);
    this.router = new ModelRouter(models.map(toModelConfig));
  }

  route(profile: TaskProfile): RoutingDecision {
    return this.router.route(profile);
  }

  async executeChat(input: {
    messages: ChatMessage[];
    profile?: TaskProfile;
    temperature?: number;
    maxTokens?: number;
    signal?: AbortSignal;
  }): Promise<ChatExecution> {
    const decision = this.router.route(input.profile ?? { needs: [] });
    const provider = this.registry.tryGet(decision.providerId);
    if (!provider) throw new Error(`Provider "${decision.providerId}" is not available`);

    // Failover list: chosen provider first, then other enabled providers.
    const ordered: AIProvider[] = [
      provider,
      ...this.registry.orderedEnabled().filter((p) => p.id !== provider.id),
    ];

    const request: ChatRequest = {
      model: decision.model.modelKey,
      messages: input.messages,
      temperature: input.temperature,
      maxTokens: input.maxTokens,
      signal: input.signal,
    };

    const started = Date.now();
    const { response, providerId, attempts } = await chatWithFallback(request, ordered);
    return { response, decision, providerId, attempts, durationMs: Date.now() - started };
  }

  /** Which capabilities a caller should request for a task profile. */
  static profileForMode(mode: string): TaskProfile {
    const map: Record<string, Capability[]> = {
      chat: ['fast'],
      deep_research: ['research', 'reasoning'],
      coding: ['coding'],
      study: ['long_context', 'reasoning'],
      reasoning: ['reasoning'],
    };
    return { needs: map[mode] ?? [] };
  }
}

function toProviderConfig(record: ProviderRecord) {
  return {
    id: record.id,
    kind: record.kind,
    label: record.label,
    baseUrl: record.baseUrl,
    apiKey: record.secret,
    headers: record.headers,
    timeoutMs: record.timeoutMs,
    enabled: record.enabled,
    priority: record.priority,
  };
}

function toModelConfig(record: {
  id: string;
  providerId: string;
  name: string;
  modelKey: string;
  capabilities: Capability[];
  contextWindow: number;
  costPer1kInput: number;
  costPer1kOutput: number;
  priority: number;
  isDefault: boolean;
  enabled: boolean;
}): ModelConfig {
  return { ...record };
}
