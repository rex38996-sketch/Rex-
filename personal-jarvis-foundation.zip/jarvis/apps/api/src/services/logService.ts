import type { Store } from '../db/store.js';
import type { ActivityLogRecord, AuditLogRecord } from '../db/records.js';

/**
 * Central logging. Every model call, tool call and admin mutation flows
 * through here so the Activity Log and Audit Log (blueprint sections 25-26)
 * stay complete without each route re-implementing them.
 */
export class LogService {
  constructor(private readonly store: Store) {}

  async activity(entry: Omit<ActivityLogRecord, 'id' | 'createdAt'>): Promise<void> {
    await this.store.activityLogs.create({ ...entry, createdAt: new Date().toISOString() });
  }

  async audit(entry: Omit<AuditLogRecord, 'id' | 'createdAt'>): Promise<void> {
    await this.store.auditLogs.create({ ...entry, createdAt: new Date().toISOString() });
  }
}
