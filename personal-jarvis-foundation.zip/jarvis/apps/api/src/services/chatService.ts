import { NotFoundError, ForbiddenError, type PublicUser } from '@jarvis/core';
import type { Store } from '../db/store.js';
import type { ConversationRecord, MessageRecord } from '../db/records.js';
import { AIService } from './aiService.js';
import type { LogService } from './logService.js';
import type { ChatMessage } from '@jarvis/ai-adapter';

export interface SendMessageInput {
  conversationId: string;
  user: PublicUser;
  content: string;
  /** Overrides the conversation's stored model for this turn. */
  modelId?: string;
  mode?: 'chat' | 'deep_research' | 'coding' | 'study' | 'reasoning';
}

export interface SendMessageResult {
  userMessage: MessageRecord;
  assistantMessage: MessageRecord;
  routing: { modelId: string; modelName: string; providerId: string; reason: string };
  usage: { inputTokens: number; outputTokens: number };
  durationMs: number;
  attempts: string[];
}

/**
 * Conversation lifecycle and the turn-by-turn orchestration loop
 * (blueprint sections 1, 2 and 42).
 */
export class ChatService {
  constructor(
    private readonly store: Store,
    private readonly ai: AIService,
    private readonly logs: LogService,
  ) {}

  async createConversation(input: {
    user: PublicUser;
    title?: string;
    agentId?: string | null;
    modelId?: string | null;
  }): Promise<ConversationRecord> {
    const now = new Date().toISOString();
    return this.store.conversations.create({
      userId: input.user.id,
      title: input.title?.trim() || 'New chat',
      folderId: null,
      status: 'active',
      pinned: false,
      agentId: input.agentId ?? null,
      modelId: input.modelId ?? null,
      useMemory: true,
      useKnowledge: true,
      useWeb: false,
      useTools: true,
      createdAt: now,
      updatedAt: now,
    });
  }

  async listConversations(user: PublicUser): Promise<ConversationRecord[]> {
    const rows = await this.store.conversations.list((c) => c.userId === user.id);
    return rows.sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return b.updatedAt.localeCompare(a.updatedAt);
    });
  }

  async getConversation(user: PublicUser, id: string): Promise<ConversationRecord> {
    const conversation = await this.store.conversations.get(id);
    if (!conversation) throw new NotFoundError('Conversation not found');
    if (conversation.userId !== user.id) throw new ForbiddenError('Not your conversation');
    return conversation;
  }

  async listMessages(user: PublicUser, conversationId: string): Promise<MessageRecord[]> {
    await this.getConversation(user, conversationId);
    const rows = await this.store.messages.list((m) => m.conversationId === conversationId);
    return rows.sort((a, b) => a.createdAt.localeCompare(b.createdAt));
  }

  async sendMessage(input: SendMessageInput): Promise<SendMessageResult> {
    const conversation = await this.getConversation(input.user, input.conversationId);

    const agent = conversation.agentId
      ? await this.store.agents.get(conversation.agentId)
      : undefined;

    const history = await this.listMessages(input.user, input.conversationId);
    const messages: ChatMessage[] = [];
    if (agent?.systemPrompt) messages.push({ role: 'system', content: agent.systemPrompt });
    for (const m of history) {
      if (m.role === 'system') continue;
      messages.push({ role: m.role === 'tool' ? 'tool' : m.role, content: m.content });
    }
    messages.push({ role: 'user', content: input.content });

    const now = new Date().toISOString();
    const userMessage = await this.store.messages.create({
      conversationId: conversation.id,
      role: 'user',
      content: input.content,
      modelId: null,
      agentId: conversation.agentId,
      citations: [],
      tokenInput: null,
      tokenOutput: null,
      createdAt: now,
    });

    const profile = AIService.profileForMode(input.mode ?? 'chat');
    if (input.modelId) profile.forceModelId = input.modelId;

    const execution = await this.ai.executeChat({
      messages,
      profile,
      temperature: agent?.temperature,
    });

    const assistantMessage = await this.store.messages.create({
      conversationId: conversation.id,
      role: 'assistant',
      content: execution.response.content,
      modelId: execution.decision.model.id,
      agentId: conversation.agentId,
      citations: [],
      tokenInput: execution.response.usage.inputTokens,
      tokenOutput: execution.response.usage.outputTokens,
      createdAt: new Date().toISOString(),
    });

    // Auto-title a brand-new conversation from its first user message.
    if (conversation.title === 'New chat' && history.length === 0) {
      await this.store.conversations.update(conversation.id, {
        title: input.content.slice(0, 60),
        updatedAt: new Date().toISOString(),
      });
    } else {
      await this.store.conversations.update(conversation.id, { updatedAt: new Date().toISOString() });
    }

    await this.logs.activity({
      userId: input.user.id,
      agentId: conversation.agentId,
      modelId: execution.decision.model.id,
      toolId: null,
      action: 'chat.completion',
      input: { conversationId: conversation.id, chars: input.content.length },
      output: { chars: execution.response.content.length },
      status: 'ok',
      error: null,
      durationMs: execution.durationMs,
    });

    return {
      userMessage,
      assistantMessage,
      routing: {
        modelId: execution.decision.model.id,
        modelName: execution.decision.model.name,
        providerId: execution.providerId,
        reason: execution.decision.reason,
      },
      usage: {
        inputTokens: execution.response.usage.inputTokens,
        outputTokens: execution.response.usage.outputTokens,
      },
      durationMs: execution.durationMs,
      attempts: execution.attempts,
    };
  }
}
