import { Router } from 'express';
import { z } from 'zod';
import type { Container } from '../container.js';
import { requireAuth, requireRole } from '../middleware/auth.js';
import { asyncHandler } from './helpers.js';

const providerSchema = z.object({
  kind: z.string().min(1),
  label: z.string().min(1),
  baseUrl: z.string().url(),
  secret: z.string().default(''),
  headers: z.record(z.string()).default({}),
  timeoutMs: z.number().int().positive().default(60000),
  enabled: z.boolean().default(true),
  priority: z.number().int().default(100),
});

const modelSchema = z.object({
  providerId: z.string().min(1),
  name: z.string().min(1),
  modelKey: z.string().min(1),
  capabilities: z.array(z.string()).default([]),
  contextWindow: z.number().int().positive().default(8192),
  costPer1kInput: z.number().nonnegative().default(0),
  costPer1kOutput: z.number().nonnegative().default(0),
  priority: z.number().int().default(0),
  isDefault: z.boolean().default(false),
  enabled: z.boolean().default(true),
});

const agentSchema = z.object({
  name: z.string().min(1),
  description: z.string().default(''),
  personality: z.string().default(''),
  systemPrompt: z.string().default(''),
  modelId: z.string().nullable().default(null),
  temperature: z.number().min(0).max(2).default(0.7),
  memoryAccess: z.boolean().default(true),
  knowledgeAccess: z.boolean().default(true),
  webAccess: z.boolean().default(false),
  fileAccess: z.boolean().default(true),
  browserAccess: z.boolean().default(false),
  computerAccess: z.boolean().default(false),
  toolIds: z.array(z.string()).default([]),
  allowedActions: z.array(z.string()).default([]),
  restrictions: z.array(z.string()).default([]),
  responseStyle: z.string().default('balanced'),
  language: z.string().default('en'),
  outputFormat: z.string().default('markdown'),
});

export function adminRoutes(container: Container): Router {
  const router = Router();
  router.use(requireAuth(), requireRole('admin'));

  // --- Providers -----------------------------------------------------------
  router.get(
    '/providers',
    asyncHandler(async (_req, res) => {
      const providers = await container.store.providers.list();
      // Never leak the secret; expose only whether one is configured.
      res.json({
        providers: providers.map(({ secret, ...rest }) => ({ ...rest, hasSecret: secret.length > 0 })),
      });
    }),
  );

  router.post(
    '/providers',
    asyncHandler(async (req, res) => {
      const body = providerSchema.parse(req.body);
      const provider = await container.store.providers.create(body);
      await container.ai.sync();
      await container.logs.audit({
        actorId: req.user!.id,
        event: 'provider.created',
        target: provider.id,
        before: null,
        after: { kind: provider.kind, label: provider.label },
      });
      const { secret: _s, ...safe } = provider;
      res.status(201).json({ provider: { ...safe, hasSecret: provider.secret.length > 0 } });
    }),
  );

  // --- Models --------------------------------------------------------------
  router.get(
    '/models',
    asyncHandler(async (_req, res) => {
      res.json({ models: await container.store.models.list() });
    }),
  );

  router.post(
    '/models',
    asyncHandler(async (req, res) => {
      const body = modelSchema.parse(req.body);
      const model = await container.store.models.create(body as never);
      await container.ai.sync();
      await container.logs.audit({
        actorId: req.user!.id,
        event: 'model.created',
        target: model.id,
        before: null,
        after: { name: model.name, modelKey: model.modelKey },
      });
      res.status(201).json({ model });
    }),
  );

  // --- Agents --------------------------------------------------------------
  router.get(
    '/agents',
    asyncHandler(async (_req, res) => {
      res.json({ agents: await container.store.agents.list() });
    }),
  );

  router.post(
    '/agents',
    asyncHandler(async (req, res) => {
      const body = agentSchema.parse(req.body);
      const now = new Date().toISOString();
      const agent = await container.store.agents.create({
        ...body,
        avatar: null,
        permissions: {
          browserRead: 'allowed',
          browserClick: 'allowed',
          browserType: 'approval_required',
          computerControl: 'approval_required',
          purchase: 'approval_required',
          delete: 'blocked',
          sendMessage: 'approval_required',
          changeSettings: 'approval_required',
          runCommand: 'approval_required',
        },
        version: 1,
        isBuiltIn: false,
        createdAt: now,
        updatedAt: now,
      } as never);
      await container.logs.audit({
        actorId: req.user!.id,
        event: 'agent.created',
        target: agent.id,
        before: null,
        after: { name: agent.name },
      });
      res.status(201).json({ agent });
    }),
  );

  // --- Logs & analytics ----------------------------------------------------
  router.get(
    '/activity',
    asyncHandler(async (_req, res) => {
      const rows = await container.store.activityLogs.list();
      res.json({ activity: rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 200) });
    }),
  );

  router.get(
    '/audit',
    asyncHandler(async (_req, res) => {
      const rows = await container.store.auditLogs.list();
      res.json({ audit: rows.sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 200) });
    }),
  );

  router.get(
    '/stats',
    asyncHandler(async (_req, res) => {
      const [users, conversations, messages, agents, models, activity] = await Promise.all([
        container.store.users.count(),
        container.store.conversations.count(),
        container.store.messages.count(),
        container.store.agents.count(),
        container.store.models.count(),
        container.store.activityLogs.count(),
      ]);
      res.json({ stats: { users, conversations, messages, agents, models, activityEvents: activity } });
    }),
  );

  return router;
}
