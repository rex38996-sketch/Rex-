import { Router } from 'express';
import { z } from 'zod';
import type { Container } from '../container.js';
import { toPublicUser } from '../auth/authService.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler } from './helpers.js';

const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8, 'Password must be at least 8 characters'),
  displayName: z.string().min(1),
});

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
});

export function authRoutes(container: Container): Router {
  const router = Router();

  router.post(
    '/register',
    asyncHandler(async (req, res) => {
      const body = registerSchema.parse(req.body);
      // First account bootstraps the Owner; everyone after defaults to User.
      const userCount = await container.store.users.count();
      const role = userCount === 0 ? 'owner' : 'user';
      const user = await container.auth.register({ ...body, role });
      const { token } = await container.auth.createSession(user.id, {
        userAgent: req.header('user-agent') ?? undefined,
        ip: req.ip,
      });
      await container.logs.audit({
        actorId: user.id,
        event: 'user.registered',
        target: user.id,
        before: null,
        after: { email: user.email, role },
      });
      res.status(201).json({ user, token });
    }),
  );

  router.post(
    '/login',
    asyncHandler(async (req, res) => {
      const body = loginSchema.parse(req.body);
      const user = await container.auth.authenticate(body.email, body.password);
      const { token } = await container.auth.createSession(user.id, {
        userAgent: req.header('user-agent') ?? undefined,
        ip: req.ip,
      });
      res.json({ user: toPublicUser(user), token });
    }),
  );

  router.post(
    '/logout',
    requireAuth(),
    asyncHandler(async (req, res) => {
      if (req.sessionToken) await container.auth.revokeSession(req.sessionToken);
      res.json({ ok: true });
    }),
  );

  router.get('/me', requireAuth(), (req, res) => {
    res.json({ user: req.user });
  });

  return router;
}
