import { Router, type Request } from 'express';
import { z } from 'zod';
import { UnauthorizedError, type PublicUser } from '@jarvis/core';
import type { Container } from '../container.js';
import { requireAuth } from '../middleware/auth.js';
import { asyncHandler } from './helpers.js';

const createConversationSchema = z.object({
  title: z.string().optional(),
  agentId: z.string().nullable().optional(),
  modelId: z.string().nullable().optional(),
});

const sendMessageSchema = z.object({
  content: z.string().min(1),
  modelId: z.string().optional(),
  mode: z.enum(['chat', 'deep_research', 'coding', 'study', 'reasoning']).optional(),
});

export function chatRoutes(container: Container): Router {
  const router = Router();
  router.use(requireAuth());

  const user = (req: Request): PublicUser => {
    if (!req.user) throw new UnauthorizedError();
    return req.user;
  };

  router.post(
    '/conversations',
    asyncHandler(async (req, res) => {
      const body = createConversationSchema.parse(req.body ?? {});
      const conversation = await container.chat.createConversation({ user: user(req), ...body });
      res.status(201).json({ conversation });
    }),
  );

  router.get(
    '/conversations',
    asyncHandler(async (req, res) => {
      res.json({ conversations: await container.chat.listConversations(user(req)) });
    }),
  );

  router.get(
    '/conversations/:id',
    asyncHandler(async (req, res) => {
      res.json({ conversation: await container.chat.getConversation(user(req), req.params.id!) });
    }),
  );

  router.get(
    '/conversations/:id/messages',
    asyncHandler(async (req, res) => {
      res.json({ messages: await container.chat.listMessages(user(req), req.params.id!) });
    }),
  );

  router.post(
    '/conversations/:id/messages',
    asyncHandler(async (req, res) => {
      const body = sendMessageSchema.parse(req.body);
      const result = await container.chat.sendMessage({
        conversationId: req.params.id!,
        user: user(req),
        content: body.content,
        modelId: body.modelId,
        mode: body.mode,
      });
      res.status(201).json(result);
    }),
  );

  return router;
}
