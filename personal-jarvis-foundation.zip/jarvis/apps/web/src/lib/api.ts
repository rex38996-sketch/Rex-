/**
 * Thin typed client for the JARVIS API. Runs in the browser; it never sees a
 * provider secret. The session token is kept in memory / localStorage by the
 * caller (Phase 1 keeps it simple; Phase 2 moves to httpOnly cookies).
 */

const BASE_FALLBACK = 'http://localhost:8787';

/**
 * Work out where the API lives.
 *
 * In a GitHub Codespace the web app is served from `<name>-3000.app.github.dev`
 * and the API from `<name>-8787.app.github.dev`. Because the browser runs on the
 * user's own device, `localhost` would point at the wrong machine — so when we
 * detect a Codespaces host we rewrite the port in the hostname automatically.
 * An explicit NEXT_PUBLIC_API_URL always wins.
 */
function resolveBaseUrl(): string {
  const configured = process.env.NEXT_PUBLIC_API_URL;
  if (configured && configured !== BASE_FALLBACK) return configured;
  if (typeof window !== 'undefined' && window.location.hostname.includes('-3000.')) {
    const apiHost = window.location.hostname.replace('-3000.', '-8787.');
    return `${window.location.protocol}//${apiHost}`;
  }
  return configured ?? BASE_FALLBACK;
}

export interface ApiError {
  error: { code: string; message: string; details?: unknown };
}

async function request<T>(path: string, init: RequestInit = {}, token?: string): Promise<T> {
  const res = await fetch(`${resolveBaseUrl()}${path}`, {
    ...init,
    headers: {
      'content-type': 'application/json',
      ...(token ? { authorization: `Bearer ${token}` } : {}),
      ...init.headers,
    },
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = json as ApiError;
    throw new Error(err?.error?.message ?? `Request failed (${res.status})`);
  }
  return json as T;
}

export const api = {
  health: () => request<{ ok: boolean }>('/health'),
  register: (body: { email: string; password: string; displayName: string }) =>
    request<{ user: any; token: string }>('/api/auth/register', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  login: (body: { email: string; password: string }) =>
    request<{ user: any; token: string }>('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify(body),
    }),
  me: (token: string) => request<{ user: any }>('/api/auth/me', {}, token),
  conversations: (token: string) =>
    request<{ conversations: any[] }>('/api/chat/conversations', {}, token),
  createConversation: (token: string) =>
    request<{ conversation: any }>(
      '/api/chat/conversations',
      { method: 'POST', body: '{}' },
      token,
    ),
  messages: (token: string, id: string) =>
    request<{ messages: any[] }>(`/api/chat/conversations/${id}/messages`, {}, token),
  send: (token: string, id: string, content: string, mode = 'chat') =>
    request<any>(
      `/api/chat/conversations/${id}/messages`,
      { method: 'POST', body: JSON.stringify({ content, mode }) },
      token,
    ),
  adminStats: (token: string) => request<{ stats: any }>('/api/admin/stats', {}, token),
  adminModels: (token: string) => request<{ models: any[] }>('/api/admin/models', {}, token),
  adminProviders: (token: string) =>
    request<{ providers: any[] }>('/api/admin/providers', {}, token),
  adminAgents: (token: string) => request<{ agents: any[] }>('/api/admin/agents', {}, token),
  adminActivity: (token: string) => request<{ activity: any[] }>('/api/admin/activity', {}, token),
};
