'use client';

import { useState } from 'react';
import { api } from '../../lib/api';

/**
 * Admin Panel shell (blueprint section 19). Phase 1 exposes live stats,
 * providers, models, agents and the activity log. Subsequent phases add the
 * remaining menu sections (memory, knowledge, tools, automation, design,
 * security, analytics, system) as they are implemented.
 */
export default function AdminPage() {
  const [token, setToken] = useState('');
  const [data, setData] = useState<{ stats?: any; providers?: any[]; models?: any[]; agents?: any[]; activity?: any[] }>({});
  const [error, setError] = useState('');

  async function load() {
    setError('');
    try {
      const [stats, providers, models, agents, activity] = await Promise.all([
        api.adminStats(token),
        api.adminProviders(token),
        api.adminModels(token),
        api.adminAgents(token),
        api.adminActivity(token),
      ]);
      setData({
        stats: stats.stats,
        providers: providers.providers,
        models: models.models,
        agents: agents.agents,
        activity: activity.activity,
      });
    } catch (e) {
      setError((e as Error).message);
    }
  }

  return (
    <main style={{ maxWidth: 900, margin: '0 auto', padding: 24 }}>
      <h1 style={{ fontSize: 22 }}>Admin Panel</h1>
      <p style={{ opacity: 0.7, fontSize: 14 }}>
        Paste an admin session token (from <code>/api/auth/login</code>) to inspect the system.
      </p>
      <div style={{ display: 'flex', gap: 8 }}>
        <input
          style={{ flex: 1, padding: 10, borderRadius: 10, border: '1px solid #24304a', background: '#0f172a', color: '#e6edf3' }}
          placeholder="Bearer token"
          value={token}
          onChange={(e) => setToken(e.target.value)}
        />
        <button onClick={load} style={{ padding: '10px 16px', borderRadius: 10, border: 'none', background: '#2563eb', color: 'white' }}>
          Load
        </button>
      </div>
      {error && <p style={{ color: '#f87171' }}>{error}</p>}

      {data.stats && (
        <section style={{ marginTop: 24 }}>
          <h2 style={{ fontSize: 16 }}>Overview</h2>
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            {Object.entries(data.stats).map(([k, v]) => (
              <div key={k} style={{ padding: '12px 16px', background: '#111827', border: '1px solid #1f2937', borderRadius: 12, minWidth: 120 }}>
                <div style={{ fontSize: 22, fontWeight: 600 }}>{String(v)}</div>
                <div style={{ opacity: 0.6, fontSize: 12 }}>{k}</div>
              </div>
            ))}
          </div>
        </section>
      )}

      <Section title="Providers" rows={data.providers} cols={['label', 'kind', 'priority', 'hasSecret']} />
      <Section title="Models" rows={data.models} cols={['name', 'modelKey', 'capabilities', 'isDefault']} />
      <Section title="Agents" rows={data.agents} cols={['name', 'responseStyle', 'version']} />
      <Section title="Recent activity" rows={data.activity} cols={['action', 'status', 'durationMs', 'createdAt']} />
    </main>
  );
}

function Section({ title, rows, cols }: { title: string; rows?: any[]; cols: string[] }) {
  if (!rows || rows.length === 0) return null;
  return (
    <section style={{ marginTop: 24 }}>
      <h2 style={{ fontSize: 16 }}>{title}</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
        <thead>
          <tr>
            {cols.map((c) => (
              <th key={c} style={{ textAlign: 'left', borderBottom: '1px solid #1f2937', padding: 6, opacity: 0.7 }}>
                {c}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, i) => (
            <tr key={i}>
              {cols.map((c) => (
                <td key={c} style={{ borderBottom: '1px solid #111827', padding: 6 }}>
                  {Array.isArray(r[c]) ? r[c].join(', ') : String(r[c] ?? '')}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}
