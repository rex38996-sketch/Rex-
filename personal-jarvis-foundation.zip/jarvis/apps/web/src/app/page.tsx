'use client';

import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { api } from '../lib/api';

interface Msg {
  role: 'user' | 'assistant';
  content: string;
  meta?: string;
}

/**
 * Phase 1 chat surface. Auth + conversation + message flow against the API.
 * Admin-configurable theming, streaming and attachments arrive in later phases.
 */
export default function ChatPage() {
  const [token, setToken] = useState('');
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authed, setAuthed] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [input, setInput] = useState('');
  const [mode, setMode] = useState('chat');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  async function doAuth() {
    setError('');
    try {
      const result =
        authMode === 'register'
          ? await api.register({
              email,
              password,
              displayName: displayName.trim() || email.split('@')[0] || 'Owner',
            })
          : await api.login({ email, password });
      setToken(result.token);
      setAuthed(true);
    } catch (e) {
      setError((e as Error).message);
    }
  }

  async function ensureConversation(): Promise<string> {
    if (conversationId) return conversationId;
    const { conversation } = await api.createConversation(token);
    setConversationId(conversation.id);
    return conversation.id;
  }

  async function send() {
    if (!input.trim() || busy) return;
    const text = input.trim();
    setInput('');
    setMessages((m) => [...m, { role: 'user', content: text }]);
    setBusy(true);
    setError('');
    try {
      const id = await ensureConversation();
      const result = await api.send(token, id, text, mode);
      setMessages((m) => [
        ...m,
        {
          role: 'assistant',
          content: result.assistantMessage.content,
          meta: `routed → ${result.routing.modelName} · ${result.usage.outputTokens} out tokens · ${result.durationMs}ms`,
        },
      ]);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (!authed) {
    const registering = authMode === 'register';
    return (
      <main style={{ maxWidth: 380, margin: '12vh auto', padding: 24 }}>
        <h1 style={{ fontSize: 22 }}>Personal JARVIS</h1>
        <p style={{ opacity: 0.7, fontSize: 14 }}>
          {registering
            ? 'Create your account — the first one becomes Owner.'
            : 'Sign in to your assistant.'}
        </p>
        {registering && (
          <input
            style={inputStyle}
            placeholder="Your name"
            value={displayName}
            onChange={(e) => setDisplayName(e.target.value)}
          />
        )}
        <input
          style={inputStyle}
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          style={inputStyle}
          placeholder="Password (min 8 characters)"
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button style={buttonStyle} onClick={doAuth}>
          {registering ? 'Create account' : 'Sign in'}
        </button>
        <p
          style={{ opacity: 0.75, fontSize: 13, marginTop: 10, cursor: 'pointer' }}
          onClick={() => {
            setError('');
            setAuthMode(registering ? 'login' : 'register');
          }}
        >
          {registering ? 'Already have an account? Sign in' : 'New here? Create an account'}
        </p>
        {error && <p style={{ color: '#f87171', fontSize: 13 }}>{error}</p>}
      </main>
    );
  }

  return (
    <main style={{ maxWidth: 760, margin: '0 auto', padding: 24, display: 'flex', flexDirection: 'column', height: '100vh' }}>
      <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <strong>JARVIS</strong>
        <a href="/admin" style={{ color: '#60a5fa', fontSize: 14 }}>
          Admin Panel →
        </a>
      </header>
      <div style={{ flex: 1, overflowY: 'auto', margin: '16px 0' }}>
        {messages.map((m, i) => (
          <div
            key={i}
            style={{
              margin: '10px 0',
              padding: '10px 14px',
              borderRadius: 12,
              background: m.role === 'user' ? '#1d283a' : '#111827',
              border: '1px solid #1f2937',
            }}
          >
            <div style={{ whiteSpace: 'pre-wrap' }}>{m.content}</div>
            {m.meta && <div style={{ opacity: 0.55, fontSize: 12, marginTop: 6 }}>{m.meta}</div>}
          </div>
        ))}
        <div ref={endRef} />
      </div>
      {error && <p style={{ color: '#f87171', fontSize: 13 }}>{error}</p>}
      <div style={{ display: 'flex', gap: 8 }}>
        <select style={{ ...inputStyle, width: 150 }} value={mode} onChange={(e) => setMode(e.target.value)}>
          <option value="chat">Chat</option>
          <option value="deep_research">Deep research</option>
          <option value="coding">Coding</option>
          <option value="study">Study</option>
          <option value="reasoning">Reasoning</option>
        </select>
        <input
          style={inputStyle}
          placeholder="Ask anything…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && send()}
        />
        <button style={buttonStyle} onClick={send} disabled={busy}>
          {busy ? '…' : 'Send'}
        </button>
      </div>
    </main>
  );
}

const inputStyle: CSSProperties = {
  width: '100%',
  padding: '10px 12px',
  borderRadius: 10,
  border: '1px solid #24304a',
  background: '#0f172a',
  color: '#e6edf3',
  marginBottom: 8,
};

const buttonStyle: CSSProperties = {
  padding: '10px 16px',
  borderRadius: 10,
  border: 'none',
  background: '#2563eb',
  color: 'white',
  cursor: 'pointer',
};
