import type { ReactNode } from 'react';

export const metadata = {
  title: 'Personal JARVIS',
  description: 'A modular, provider-independent personal AI assistant platform.',
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body
        style={{
          margin: 0,
          fontFamily: 'system-ui, -apple-system, Segoe UI, Roboto, sans-serif',
          background: '#0b0f17',
          color: '#e6edf3',
        }}
      >
        {children}
      </body>
    </html>
  );
}
