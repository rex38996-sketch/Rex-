# Roadmap

Build in phases, test each phase before starting the next (blueprint sections 53
and 54). The foundation (Phase 1) is implemented and tested. Everything below
builds on it without reworking what exists.

Legend: ✅ done · 🚧 next · ⬜ planned

## Phase 1 — Foundation ✅

Project setup, authentication, database schema, basic UI, chat, AI adapter,
admin login.

Delivered: monorepo + workspaces, full Prisma schema, provider-independent AI
layer (registry, router, failover, mock + OpenAI-compatible adapters), scrypt
auth with hashed sessions, role-based access, chat orchestration, admin API
(providers, models, agents, stats, logs), Next.js chat + admin shell, and a
29-test suite with typecheck and schema validation passing.

## Phase 2 — Admin & persistence 🚧

- Prisma-backed `Repository` implementation behind the existing interface
- Migrations and a seed script; move off the in-memory store
- Admin Panel sections: dashboard, settings, models, prompts, agents, theme
- System prompt manager with versioning, draft/publish and rollback

## Phase 3 — Memory ⬜

- Short-term and long-term memory; episodic and semantic kinds
- Memory modes: auto-save, ask-before-save, manual-only, disabled
- Memory manager: view/search/edit/delete, pin/lock/approve, import/export
- Retrieval feeding the orchestrator, with importance and confidence

## Phase 4 — Knowledge ⬜

- Upload/import: books, PDFs, DOCX, TXT, notes, web pages, papers, scans
- Pipeline: parse → OCR → clean → chunk → metadata → embeddings → vector DB
- Hybrid search (semantic + keyword) with metadata filters
- Answer with citations (document, chapter, page, section)
- Deep Knowledge Mode: cross-book comparison, summaries, flashcards, quizzes

## Phase 5 — Tools ⬜

- Web search, files, HTTP/custom APIs, code execution, calculator, database
- Tool Manager: enable/configure/rename/permission/test/limits
- Custom Tool Builder; API Manager with usage monitoring and limits

## Phase 6 — Agents ⬜

- Custom Agent Builder (personality, prompt, model, access, restrictions)
- Agent versioning and cloning
- Router-driven multi-agent workflows

## Phase 7 — Automation ⬜

- Scheduled tasks (daily/weekly/monthly/date), event and webhook triggers
- Workflow builder: visual graph, conditional branches
- Flow: Trigger → Planner → Agent → Tools → Result → Notification

## Phase 8 — Voice ⬜

- Speech-to-text input and text-to-speech output
- Multiple voices, speed, pitch, language
- Push-to-talk, continuous conversation, wake word, hands-free

## Phase 9 — Browser & Computer agents ⬜

- Browser agent: open, search, read, click, type, navigate, extract
- Computer agent: screen → vision → plan → action → verify
- Approval system and permission levels for sensitive actions

## Phase 10 — Polish ⬜

- Premium UI, animations, performance
- Security hardening, backups/restore, import/export
- Full analytics: usage, tokens, costs, performance, errors
- Deployment

## Standing rules for every phase

- Keep frontend, backend, database, orchestration, memory, knowledge, tools,
  agents, automation and admin modular.
- Never hard-code a provider or model into the application.
- Every major subsystem is configurable from the Admin Panel.
- Preserve backwards compatibility when adding features.
- Add tests, error handling, logging, permissions, approval gates and secure
  server-side secret management.
- Build and test one phase at a time.
