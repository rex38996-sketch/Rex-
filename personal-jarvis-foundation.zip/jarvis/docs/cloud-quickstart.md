# Run in the cloud (no computer required)

This guide runs the project entirely from a phone or any browser — no local
install. It uses **GitHub Codespaces**, which gives you a real Linux machine
with Node, a terminal and an editor, all inside the browser. Replit and Termux
notes are at the end.

## Zero-typing setup (recommended on a phone)

Add a `.devcontainer/devcontainer.json` file to the repository root (GitHub web:
**Add file → Create new file**, type the path, paste the contents, commit). Then
create a Codespace — it will unzip the project, install dependencies and start
both servers automatically, with no terminal typing at all. The API is
auto-forwarded on port 8787 and the web app on port 3000.

## Manual setup

## 1. One-time setup

1. Create a free account at [github.com](https://github.com).
2. Create a new **private** repository, e.g. `personal-jarvis`.
3. Upload the project zip: on the repo page → **Add file → Upload files** →
   choose `personal-jarvis-foundation.zip` → **Commit changes**.

## 2. Open a Codespace

1. On the repo page, click the green **Code** button.
2. Open the **Codespaces** tab → **Create codespace on main**.
3. VS Code opens in the browser. On a phone, turn on **Desktop site** in your
   browser menu so the layout is usable.
4. Open a terminal: **☰ menu → Terminal → New Terminal** (or `` Ctrl+` ``).

## 3. Start the API

In the terminal:

```bash
unzip personal-jarvis-foundation.zip
cd jarvis
npm install
cp .env.example .env
npm run start:api
```

You should see `Personal JARVIS API listening on http://localhost:8787`.
Codespaces detects the port and shows a popup — click **Open in Browser**. If
not, go to the **Ports** tab, find port **8787**, and click the globe icon.
To let anyone open it, right-click the port → **Port Visibility → Public**.

Quick check from the terminal:

```bash
curl -s localhost:8787/health
# {"ok":true,"env":"development","version":"0.1.0"}
```

## 4. Start the web app (optional but recommended)

Open a second terminal, then:

```bash
cd jarvis
NEXT_PUBLIC_API_URL="https://<your-codespace>-8787.app.github.dev" \
  npm run dev --workspace @jarvis/web
```

- Replace `<your-codespace>-8787.app.github.dev` with the **public** URL of
  port 8787 (copy it from the Ports tab). The web app needs this because the
  browser runs on your phone, where `localhost` is not the Codespace.
- Open the forwarded URL for port **3000**.
- The API already sends permissive CORS headers in non-production, so the
  browser is allowed to call it.

## 5. Create your account

Register in the web app (or via `curl`). The **first account becomes the
Owner** and gets full Admin Panel access at `/admin`.

## 6. Coming back later

A Codespace stops automatically after inactivity. To resume: repo → **Code →
Codespaces →** pick your codespace → **Resume**. Data lives in memory in
Phase 1, so conversations reset when the process restarts.

Free personal accounts include a limited monthly quota of Codespaces hours and
storage; check your GitHub billing settings for current limits.

## Alternatives

**Replit** — create an account, choose **Import**, upload the zip, then run
`npm install` and `npm run start:api` in the Shell. Ports are exposed
automatically.

**Termux (Android only)** — install Termux from **F-Droid** (the Play Store
build is outdated), then:

```bash
pkg update && pkg upgrade
pkg install nodejs unzip
unzip personal-jarvis-foundation.zip
cd jarvis && npm install
npm run start:api
```

Open a new Termux session for the web app. The backend runs fine; the Next.js
frontend is heavier on a phone.

**iPhone** — Termux is not available; use Codespaces or Replit in Safari.
