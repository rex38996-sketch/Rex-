# Admin Panel

The Admin Panel is the control surface for the whole platform. The guiding
principle (blueprint sections 48 and 54) is that **every major subsystem is
configurable without code changes**. This document maps the menu to its
implementation status.

## Menu map

```
DASHBOARD

AI           Models · Model Router · Agents · Prompts · AI Settings
MEMORY       Memories · Memory Rules · Memory Settings
KNOWLEDGE    Knowledge Bases · Books · Documents · Sources · Search
TOOLS        Tool Library · Browser · Computer · APIs · Custom Tools
AUTOMATION   Workflows · Scheduled Tasks · Triggers · Jobs
VOICE        Speech-to-Text · Text-to-Speech · Voice Settings
DESIGN       Theme · Branding · Layout · Chat UI · Components
DATA         Files · Database · Imports · Exports
SECURITY     Permissions · API Keys · Sessions · Approvals · Security Logs
ANALYTICS    Usage · Tokens · Costs · Performance · Errors
SYSTEM       General Settings · Feature Flags · Logs · Backups · System Health
```

## Access control

Only `admin` and above reach the panel at all (`requireRole('admin')`). The
Owner has full access. Sensitive mutations write an audit entry
(`AuditLog`) automatically.

## Implemented in Phase 1

| Area | Endpoint | Notes |
| --- | --- | --- |
| Dashboard stats | `GET /api/admin/stats` | users, conversations, messages, agents, models, activity count |
| Providers | `GET/POST /api/admin/providers` | secrets never returned; only `hasSecret` |
| Models | `GET/POST /api/admin/models` | capabilities, context, cost, priority, default |
| Agents | `GET/POST /api/admin/agents` | full agent configuration |
| Activity log | `GET /api/admin/activity` | every model/tool call |
| Audit log | `GET /api/admin/audit` | security-sensitive events |

The web shell at `/admin` renders stats, providers, models, agents and the
activity log from these endpoints.

## The admin control principle

For every major subsystem, the panel should support: view, create, edit,
duplicate, enable, disable, delete, export, import, test, version, rollback.

Phase 1 implements view/create for providers, models and agents, plus the logs
and stats that underpin the dashboard. The remaining operations and menu
sections are delivered in the phases listed in `ROADMAP.md` — no foundation
rework is required to add them.

## Model Router

The router is configured indirectly through models: each model carries
capability tags (`reasoning`, `coding`, `vision`, `long_context`, `fast`,
`cheap`, `research`, `audio`), a priority and a default flag. The router scores
models against a task profile, so "simple → fast, complex → reasoning" is a data
configuration, not code.
