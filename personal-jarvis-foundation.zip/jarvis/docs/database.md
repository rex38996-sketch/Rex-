# Database

The logical model lives in `prisma/schema.prisma`. It targets PostgreSQL with
the `pgvector` extension (enabled via the `postgresqlExtensions` preview
feature) and is organised into three storage tiers.

## Storage tiers

| Tier | Technology | Holds |
| --- | --- | --- |
| Relational | PostgreSQL | users, sessions, conversations, messages, agents, models, providers, tools, workflows, logs, settings |
| Vector | pgvector (same instance) | memory and knowledge embeddings for retrieval |
| Object | S3-compatible | uploaded PDFs, documents, images, audio, video, files |

## Entity groups

**Identity & access** — `User`, `Session`, `Role`, `Permission`.

**Conversations** — `Conversation` (with per-conversation toggles for memory,
knowledge, web and tools), `Folder` (nested), `Message` (citations stored as
JSON).

**Agents** — `Agent` and `AgentVersion` (full JSON snapshots for versioning and
rollback).

**Models & providers** — `ApiProvider`, `ApiCredential`, `Model`. Credentials
store only ciphertext; plaintext secrets never reach the database.

**Memory** — `Memory` and `MemoryEmbedding` (vector column). Memory carries
kind, category, importance, confidence, source, and pin/lock/approve flags.

**Knowledge** — `KnowledgeBase`, `Document` (with `version` and pipeline
`status`), `DocumentChunk` (chapter/page/section), `Embedding` (vector column).

**Tools** — `Tool` (kind: builtin/http/custom/mcp, with input schema and a
`requiresConfirmation` gate).

**Automation** — `Workflow`, `WorkflowRun`, `Task`, `ScheduledTask`.

**Approvals & logs** — `ApprovalRequest`, `ActivityLog`, `AuditLog`.

**Presentation & system** — `Setting`, `Theme`, `Notification`, `Backup`.

## Versioning

Documents and agents are versioned (`Document.version`, `AgentVersion`) so a
specific revision can be selected or restored — blueprint sections 44 and 16.

## Phase 1 vs. Phase 2

Phase 1 runs on an in-memory implementation of the `Repository` interface
(`apps/api/src/db/store.ts`) so the platform is runnable and testable without a
database. Phase 2 adds a Prisma-backed implementation of the same interface;
services and agent logic do not change.

## Validating

```bash
DATABASE_URL="postgresql://jarvis:jarvis@localhost:5432/jarvis?schema=public" \
  npm run db:validate
```

## Migrating (Phase 2)

```bash
npx prisma migrate dev --name init
npx prisma generate
```
