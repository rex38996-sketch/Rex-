# Architecture

This document explains how the pieces fit together and, more importantly, where
the seams are — the boundaries that let a subsystem be replaced without
disturbing the rest.

## The request path

```
Client (web / curl)
   │  HTTP + Bearer token
   ▼
apps/api  ── express ──▶ attachUser ──▶ routes ──▶ services ──▶ Repository (data)
                                              │
                                              └──▶ AIService ──▶ ProviderRegistry ──▶ AIProvider
                                                     │                                  │
                                                     └──▶ ModelRouter                   └── mock / openai-compatible / ...
```

A chat turn, step by step (blueprint section 2):

1. **Route** `POST /api/chat/conversations/:id/messages` validates input (zod).
2. **ChatService** loads the conversation, checks ownership, and assembles the
   message history plus any agent system prompt.
3. **AIService** asks the **ModelRouter** which model fits the task profile for
   the requested mode (`chat`, `deep_research`, `coding`, `study`, `reasoning`).
4. **AIService** calls the chosen provider, and on failure **fails over** to the
   other enabled providers in priority order.
5. The reply, token usage and routing decision are persisted and returned; an
   **activity log** entry is written.

## Layer boundaries

### 1. `packages/core` — pure domain

No framework, no database, no provider. It holds the shared types and the pure
rules that everything depends on: the role hierarchy and the permission engine.
Because it is pure, it is exhaustively unit-testable and safe to share between
frontend and backend later.

### 2. `packages/ai-adapter` — provider independence

The single most important boundary. The rest of the application imports only
from this package and never from a vendor SDK.

- `AIProvider` — the contract: `chat`, `chatStream`, `embed`, `listModels`,
  `healthCheck`.
- `ProviderRegistry` — maps an adapter `kind` (e.g. `openai_compatible`) to a
  factory, and holds live instances built from database-stored config.
- `ModelRouter` — scores configured models against a task profile and picks one.
- `chatWithFallback` — tries providers in order until one succeeds.

Adding a vendor = write one adapter + `registry.register('kind', factory)`.
Nothing else changes. This is what makes "changing an AI provider must not
require rebuilding the application" true.

### 3. `apps/api` — orchestration and policy

- `container.ts` — the composition root; wires store, auth, AI, chat and logging
  once so routes stay thin and the graph is mockable in tests.
- `db/` — the `Repository` interface and an in-memory implementation. A Prisma
  implementation of the same interface lands in Phase 2; services never change.
- `auth/` — scrypt password hashing, opaque session tokens stored only as
  SHA-256 hashes, session resolution and revocation.
- `middleware/` — `attachUser`, `requireAuth`, `requireRole`, and a terminal
  error handler that maps typed errors to clean JSON.
- `services/` — `AIService` (orchestrator), `ChatService` (conversation loop),
  `LogService` (activity + audit).
- `routes/` — thin HTTP handlers: `auth`, `chat`, `admin`.

### 4. `apps/web` — presentation

Talks only to the HTTP API. Contains no business logic and no secrets. The chat
page and Admin Panel shell are Phase 1; theming, streaming UI and the remaining
admin sections arrive later.

### 5. `prisma/schema.prisma` — storage contract

The full logical data model, expressed once. Storage splits into three tiers
(blueprint section 37): a relational database for users/settings/chats/metadata,
a vector store (pgvector) for memory and knowledge retrieval, and object storage
for uploaded files.

## Cross-cutting concerns

**Security.** Secrets are server-side only and never serialised to clients — the
admin providers endpoint returns a `hasSecret` boolean instead of the key.
Passwords use scrypt; session tokens are stored hashed; every admin mutation
writes an audit entry.

**Permissions.** Roles are ranked (`owner > super_admin > admin > editor > user
> guest`). The permission engine resolves an agent's configured policy against
the acting user's role, and `blocked` always wins. `approval_required` is
preserved so the approval system (Phase 9) can gate sensitive actions.

**Observability.** `LogService` records activity (every model/tool call) and
audit (security-sensitive admin events) uniformly.

**Errors.** `packages/core` defines a typed error hierarchy (`ValidationError`,
`UnauthorizedError`, `ForbiddenError`, `NotFoundError`, `ApprovalRequiredError`)
that the API maps to HTTP status codes in one place.

## Deliberate Phase 1 simplifications

These are choices, not oversights, and each has a planned replacement:

- **In-memory store** instead of Postgres — keeps the foundation runnable and
  testable with zero infrastructure. Swapped in Phase 2 behind the same interface.
- **Bearer tokens in memory/localStorage** on the web client — Phase 2 moves to
  httpOnly cookies.
- **Mock provider by default** — the platform runs with no credentials; a real
  OpenAI-compatible provider is registered automatically when a key is present.
