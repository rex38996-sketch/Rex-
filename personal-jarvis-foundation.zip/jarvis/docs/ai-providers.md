# AI providers

The platform is provider-independent by construction. The application imports
only from `@jarvis/ai-adapter` and never from a vendor SDK. Providers are
records in the database, created from the Admin Panel (or the seeder), and the
adapter turns each record into a live client.

## The contract

Every provider implements `AIProvider`:

```ts
interface AIProvider {
  readonly id: string;
  readonly kind: string;
  readonly label: string;
  chat(request: ChatRequest): Promise<ChatResponse>;
  chatStream(request: ChatRequest): AsyncIterable<ChatStreamEvent>;
  embed(request: EmbeddingRequest): Promise<EmbeddingResponse>;
  listModels(): Promise<ProviderModel[]>;
  healthCheck(): Promise<ProviderHealth>;
}
```

## Built-in adapters

**`mock`** — deterministic, dependency-free. Used for local development and the
test suite so the platform runs end to end with no credentials.

**`openai_compatible`** — speaks the OpenAI HTTP wire format, so one adapter
covers OpenAI, Azure OpenAI, Groq, Together, OpenRouter and local
vLLM/Ollama endpoints. Configure `baseUrl`, `apiKey`, optional `headers` and a
timeout.

## Adding a provider (no app rebuild)

1. Write an adapter module exporting a `ProviderFactory`.
2. Register it once:

   ```ts
   registry.register('my_vendor', createMyVendorProvider);
   ```

3. Create a provider record from the Admin Panel with `kind: "my_vendor"`.
4. Add model records pointing at that provider.

Nothing in memory, tools, chat or the UI changes. This is the guarantee in
blueprint section 39.

## Routing and failover

`ModelRouter` selects a model for a task profile (the capabilities the task
needs). `chatWithFallback` then calls the chosen provider and, on failure, tries
the other enabled providers in ascending priority order — the fallback chain
from blueprint sections 33–34.

## Security

Provider credentials are stored as ciphertext and resolved server-side only. The
admin providers endpoint never returns the secret; it returns `hasSecret`. Keys
never appear in frontend code or logs.
